#[cfg(feature = "dispatch-trace")]
fn word_is_power_of(mut value: u128, factor: u128) -> bool {
    while value.is_multiple_of(factor) {
        value /= factor;
    }
    value == 1
}

#[cfg(feature = "dispatch-trace")]
fn word_is_smooth_357(mut value: u128) -> bool {
    for factor in [3_u128, 5, 7] {
        while value.is_multiple_of(factor) {
            value /= factor;
        }
    }
    value == 1
}

#[derive(Clone, Debug)]
struct HalfGcdMatrix {
    u00: BigUint,
    u01: BigUint,
    u10: BigUint,
    u11: BigUint,
}

impl HalfGcdMatrix {
    fn identity() -> Self {
        Self {
            u00: BigUint::one(),
            u01: BigUint::ZERO,
            u10: BigUint::ZERO,
            u11: BigUint::one(),
        }
    }

    fn apply_inverse(&self, left: &BigUint, right: &BigUint) -> Option<(BigUint, BigUint)> {
        let first_positive =
            Rational::multiply_magnitudes("half-gcd-matrix-apply", &self.u11, left);
        let first_negative =
            Rational::multiply_magnitudes("half-gcd-matrix-apply", &self.u01, right);
        let second_positive =
            Rational::multiply_magnitudes("half-gcd-matrix-apply", &self.u00, right);
        let second_negative =
            Rational::multiply_magnitudes("half-gcd-matrix-apply", &self.u10, left);
        if first_positive < first_negative || second_positive < second_negative {
            return None;
        }
        Some((
            first_positive - first_negative,
            second_positive - second_negative,
        ))
    }

    fn multiply_right(&mut self, right: &Self) {
        let u00 = Rational::multiply_magnitudes("half-gcd-matrix-compose", &self.u00, &right.u00)
            + Rational::multiply_magnitudes(
                "half-gcd-matrix-compose",
                &self.u01,
                &right.u10,
            );
        let u01 = Rational::multiply_magnitudes("half-gcd-matrix-compose", &self.u00, &right.u01)
            + Rational::multiply_magnitudes(
                "half-gcd-matrix-compose",
                &self.u01,
                &right.u11,
            );
        let u10 = Rational::multiply_magnitudes("half-gcd-matrix-compose", &self.u10, &right.u00)
            + Rational::multiply_magnitudes(
                "half-gcd-matrix-compose",
                &self.u11,
                &right.u10,
            );
        let u11 = Rational::multiply_magnitudes("half-gcd-matrix-compose", &self.u10, &right.u01)
            + Rational::multiply_magnitudes(
                "half-gcd-matrix-compose",
                &self.u11,
                &right.u11,
            );
        (self.u00, self.u01, self.u10, self.u11) = (u00, u01, u10, u11);
    }

    fn update_left_column(&mut self, quotient: &BigUint) {
        self.u00 += Rational::multiply_magnitudes(
            "half-gcd-matrix-column-update",
            &self.u01,
            quotient,
        );
        self.u10 += Rational::multiply_magnitudes(
            "half-gcd-matrix-column-update",
            &self.u11,
            quotient,
        );
    }

    fn update_right_column(&mut self, quotient: &BigUint) {
        self.u01 += Rational::multiply_magnitudes(
            "half-gcd-matrix-column-update",
            &self.u00,
            quotient,
        );
        self.u11 += Rational::multiply_magnitudes(
            "half-gcd-matrix-column-update",
            &self.u10,
            quotient,
        );
    }
}

struct HalfGcdReduction {
    left: BigUint,
    right: BigUint,
    matrix: HalfGcdMatrix,
}

struct DyadicProductSumPlan<const TERMS: usize> {
    denominator_shifts: [u64; TERMS],
    max_shift: u64,
    prefer_wide: bool,
}

const DYADIC_STACK_LIMBS: usize = 6;

// Keep the common geometry envelope allocation-free through 384 bits. Every
// operation is checked; operands, alignment, or carries outside this bound
// return to the arbitrary-precision reducer without changing the result.
#[derive(Clone, Copy, Debug, Default)]
struct DyadicStackAccumulator([u64; DYADIC_STACK_LIMBS]);

#[derive(Clone, Copy, Debug)]
struct DyadicStackSum {
    sign: Sign,
    magnitude: DyadicStackAccumulator,
    denominator_shift: u64,
}

#[derive(Clone, Copy, Debug)]
struct DyadicWord {
    sign: Sign,
    magnitude: u128,
    denominator_shift: u64,
}

#[derive(Clone, Copy)]
struct DyadicLineIntersectionPlan {
    first_start: [DyadicWord; 2],
    first_delta: [DyadicWord; 2],
    denominator: DyadicWord,
    numerators: [DyadicWord; 2],
}

/// Exact-dyadic source line for repeated intersection queries.
///
/// The compact endpoint words and their exact delta are retained without
/// materializing standalone rational differences. Queries that exceed this
/// native-word envelope return `None` for the general exact fallback.
#[derive(Clone, Copy, Debug)]
#[doc(hidden)]
pub struct ExactDyadicLine2 {
    start: [DyadicWord; 2],
    delta: [DyadicWord; 2],
}

#[derive(Clone, Copy, Debug)]
struct DyadicWideWord {
    sign: Sign,
    magnitude: [u64; 4],
    denominator_shift: u64,
}

#[derive(Clone, Copy)]
struct DyadicWideLineIntersectionPlan {
    first_start: [DyadicWord; 2],
    first_delta: [DyadicWord; 2],
    denominator: DyadicWideWord,
    numerators: [DyadicWideWord; 2],
}

/// Compact exact parameters for a line crossing whose inputs are dyadic.
///
/// The determinant quotients stay in their native word representation so
/// geometry layers can order crossings without constructing reduced
/// rationals. Parameters are materialized only when an API exposes them.
#[doc(hidden)]
#[derive(Clone, Debug)]
pub struct ExactDyadicLineParameters2 {
    numerator_magnitudes: [u128; 2],
    denominator_magnitude: u128,
    denominator_shifts: [u64; 3],
    signs: [Sign; 3],
}

/// Deferred exact coordinates for a line crossing with a native-word
/// determinant.
///
/// The affine coordinate numerators stay in the fixed-stack representation
/// used by the intersection kernel. Geometry layers can retain this carrier
/// without allocating arbitrary-precision rationals and materialize the two
/// coordinates only if they are observed.
#[doc(hidden)]
#[derive(Clone, Copy, Debug)]
pub struct ExactDyadicLinePoint2 {
    coordinate_numerators: [DyadicStackSum; 2],
    denominator_magnitude: u128,
    denominator_shift: u64,
    denominator_sign: Sign,
}

/// Wider compact exact parameters for dyadic line crossings whose determinant
/// does not fit the native-word carrier.
///
/// Geometry layers normally box this uncommon representation so the dominant
/// inline crossing event stays compact.
#[doc(hidden)]
#[derive(Clone, Debug)]
pub struct ExactDyadicWideLineParameters2 {
    numerator_magnitudes: [[u64; 4]; 2],
    denominator_magnitude: [u64; 4],
    denominator_shifts: [u64; 3],
    signs: [Sign; 3],
}

/// Deferred exact coordinates for a line crossing with a wide determinant.
#[doc(hidden)]
#[derive(Clone, Copy, Debug)]
pub struct ExactDyadicWideLinePoint2 {
    coordinate_numerators: [DyadicStackSum; 2],
    denominator_magnitude: [u64; 4],
    denominator_shift: u64,
    denominator_sign: Sign,
}

impl ExactDyadicLinePoint2 {
    pub(crate) fn materialize_rationals(&self) -> [Rational; 2] {
        self.coordinate_numerators.map(|numerator| {
            if numerator.sign == NoSign {
                Rational::zero()
            } else {
                Rational::quotient_dyadic_stack_sum_unreduced(
                    numerator,
                    self.denominator_sign,
                    self.denominator_shift,
                    self.denominator_magnitude,
                )
            }
        })
    }
}

impl ExactDyadicWideLinePoint2 {
    fn denominator(&self) -> DyadicWideWord {
        DyadicWideWord {
            sign: self.denominator_sign,
            magnitude: self.denominator_magnitude,
            denominator_shift: self.denominator_shift,
        }
    }

    pub(crate) fn materialize_rationals(&self) -> [Rational; 2] {
        let denominator = self.denominator();
        self.coordinate_numerators.map(|numerator| {
            if numerator.sign == NoSign {
                Rational::zero()
            } else {
                Rational::quotient_dyadic_stack_sum_by_wide_unreduced(numerator, denominator)
            }
        })
    }
}

impl ExactDyadicLineParameters2 {
    fn from_words(numerators: [DyadicWord; 2], denominator: DyadicWord) -> Self {
        Self {
            numerator_magnitudes: [numerators[0].magnitude, numerators[1].magnitude],
            denominator_magnitude: denominator.magnitude,
            denominator_shifts: [
                numerators[0].denominator_shift,
                numerators[1].denominator_shift,
                denominator.denominator_shift,
            ],
            signs: [numerators[0].sign, numerators[1].sign, denominator.sign],
        }
    }

    fn numerator(&self, index: usize) -> DyadicWord {
        DyadicWord {
            sign: self.signs[index],
            magnitude: self.numerator_magnitudes[index],
            denominator_shift: self.denominator_shifts[index],
        }
    }

    fn denominator(&self) -> DyadicWord {
        DyadicWord {
            sign: self.signs[2],
            magnitude: self.denominator_magnitude,
            denominator_shift: self.denominator_shifts[2],
        }
    }

    #[inline]
    fn multiply_magnitudes(left: u128, right: u128) -> [u64; 4] {
        let left = [left as u64, (left >> 64) as u64];
        let right = [right as u64, (right >> 64) as u64];
        let mut product = [0_u64; 4];
        for (left_index, left_limb) in left.into_iter().enumerate() {
            let mut carry = 0_u128;
            for (right_index, right_limb) in right.into_iter().enumerate() {
                let index = left_index + right_index;
                let total = u128::from(product[index])
                    + u128::from(left_limb) * u128::from(right_limb)
                    + carry;
                product[index] = total as u64;
                carry = total >> 64;
            }
            let index = left_index + 2;
            let total = u128::from(product[index]) + carry;
            product[index] = total as u64;
            debug_assert_eq!(total >> 64, 0);
        }
        product
    }

    #[inline]
    fn product_bit_length(product: &[u64; 4]) -> u128 {
        let index = product
            .iter()
            .rposition(|limb| *limb != 0)
            .expect("nonzero parameter product has a nonzero limb");
        u128::try_from(index * 64 + (64 - product[index].leading_zeros() as usize))
            .expect("fixed product bit length fits u128")
    }

    #[inline]
    fn compare_normalized_products(
        left: [u64; 4],
        left_bit_length: u128,
        right: [u64; 4],
        right_bit_length: u128,
    ) -> Ordering {
        let left_shift = u32::try_from(256 - left_bit_length)
            .expect("four-limb product normalization shift fits u32");
        let right_shift = u32::try_from(256 - right_bit_length)
            .expect("four-limb product normalization shift fits u32");
        let normalized_limb = |product: &[u64; 4], shift: u32, target: usize| {
            let word_shift = (shift / 64) as usize;
            if target < word_shift {
                return 0;
            }
            let source = target - word_shift;
            let bit_shift = shift % 64;
            let mut limb = product[source] << bit_shift;
            if bit_shift != 0 && source != 0 {
                limb |= product[source - 1] >> (64 - bit_shift);
            }
            limb
        };
        for target in (0..4).rev() {
            let ordering = normalized_limb(&left, left_shift, target)
                .cmp(&normalized_limb(&right, right_shift, target));
            if ordering != Ordering::Equal {
                return ordering;
            }
        }
        Ordering::Equal
    }

    #[cold]
    #[inline(never)]
    fn compare_parameter_normalized(&self, index: usize, other: &Self) -> Ordering {
        let left_numerator = self.numerator(index);
        let right_numerator = other.numerator(index);
        let left_denominator = self.denominator();
        let right_denominator = other.denominator();
        let left_sign = left_numerator.sign * left_denominator.sign;
        let right_sign = right_numerator.sign * right_denominator.sign;
        if left_sign != right_sign {
            return match (left_sign, right_sign) {
                (Minus, _) | (_, Plus) => Ordering::Less,
                (Plus, _) | (_, Minus) => Ordering::Greater,
                _ => Ordering::Equal,
            };
        }
        if left_sign == NoSign {
            return Ordering::Equal;
        }

        let left_shift = u128::from(left_denominator.denominator_shift)
            + u128::from(right_numerator.denominator_shift);
        let right_shift = u128::from(right_denominator.denominator_shift)
            + u128::from(left_numerator.denominator_shift);
        let left =
            Self::multiply_magnitudes(left_numerator.magnitude, right_denominator.magnitude);
        let right =
            Self::multiply_magnitudes(right_numerator.magnitude, left_denominator.magnitude);
        let left_bit_length = Self::product_bit_length(&left);
        let right_bit_length = Self::product_bit_length(&right);
        let ordering =
            match (left_bit_length + left_shift).cmp(&(right_bit_length + right_shift)) {
                Ordering::Equal => Self::compare_normalized_products(
                    left,
                    left_bit_length,
                    right,
                    right_bit_length,
                ),
                ordering => ordering,
            };
        if left_sign == Minus {
            ordering.reverse()
        } else {
            ordering
        }
    }

    fn compare_parameter(&self, index: usize, other: &Self) -> Ordering {
        let left_numerator = self.numerator(index);
        let right_numerator = other.numerator(index);
        let left_denominator = self.denominator();
        let right_denominator = other.denominator();
        let left_sign = left_numerator.sign * left_denominator.sign;
        let right_sign = right_numerator.sign * right_denominator.sign;
        if left_sign != right_sign {
            return match (left_sign, right_sign) {
                (Minus, _) | (_, Plus) => Ordering::Less,
                (Plus, _) | (_, Minus) => Ordering::Greater,
                _ => Ordering::Equal,
            };
        }
        if left_sign == NoSign {
            return Ordering::Equal;
        }

        let left_shift = u128::from(left_denominator.denominator_shift)
            + u128::from(right_numerator.denominator_shift);
        let right_shift = u128::from(right_denominator.denominator_shift)
            + u128::from(left_numerator.denominator_shift);
        let exponent_ordering = if left_shift >= right_shift + 256 {
            Some(Ordering::Greater)
        } else if right_shift >= left_shift + 256 {
            Some(Ordering::Less)
        } else {
            None
        };
        let common_shift = left_shift.min(right_shift);
        let mut left = DyadicStackAccumulator::default();
        let mut right = DyadicStackAccumulator::default();
        let ordering = exponent_ordering.unwrap_or_else(|| match (
            left.add_product(
                left_numerator.magnitude,
                right_denominator.magnitude,
                u64::try_from(left_shift - common_shift)
                    .expect("bounded dyadic comparison shift fits u64"),
            ),
            right.add_product(
                right_numerator.magnitude,
                left_denominator.magnitude,
                u64::try_from(right_shift - common_shift)
                    .expect("bounded dyadic comparison shift fits u64"),
            ),
        ) {
            (Some(()), Some(())) => left.0.iter().rev().cmp(right.0.iter().rev()),
            _ => {
                let mut left =
                    BigUint::from(left_numerator.magnitude) * right_denominator.magnitude;
                let mut right =
                    BigUint::from(right_numerator.magnitude) * left_denominator.magnitude;
                left <<= usize::try_from(left_shift - common_shift)
                    .expect("bounded dyadic comparison shift fits usize");
                right <<= usize::try_from(right_shift - common_shift)
                    .expect("bounded dyadic comparison shift fits usize");
                left.cmp(&right)
            }
        });
        if left_sign == Minus {
            ordering.reverse()
        } else {
            ordering
        }
    }

    /// Compare the parameter on the first source line without reducing it.
    pub fn compare_first_parameter(&self, other: &Self) -> Ordering {
        self.compare_parameter(0, other)
    }

    /// Compare the parameter on the second source line without reducing it.
    pub fn compare_second_parameter(&self, other: &Self) -> Ordering {
        self.compare_parameter(1, other)
    }

    /// Compare the first parameter through normalized fixed-width products.
    #[doc(hidden)]
    pub fn compare_first_parameter_normalized(&self, other: &Self) -> Ordering {
        self.compare_parameter_normalized(0, other)
    }

    /// Compare the second parameter through normalized fixed-width products.
    #[doc(hidden)]
    pub fn compare_second_parameter_normalized(&self, other: &Self) -> Ordering {
        self.compare_parameter_normalized(1, other)
    }

    pub(crate) fn materialize_parameter(&self, index: usize) -> Rational {
        Rational::quotient_dyadic_words(self.numerator(index), self.denominator())
            .expect("retained dyadic line parameter remains representable")
            .0
    }
}

impl ExactDyadicWideLineParameters2 {
    fn from_words(numerators: [DyadicWideWord; 2], denominator: DyadicWideWord) -> Self {
        Self {
            numerator_magnitudes: [numerators[0].magnitude, numerators[1].magnitude],
            denominator_magnitude: denominator.magnitude,
            denominator_shifts: [
                numerators[0].denominator_shift,
                numerators[1].denominator_shift,
                denominator.denominator_shift,
            ],
            signs: [numerators[0].sign, numerators[1].sign, denominator.sign],
        }
    }

    fn numerator(&self, index: usize) -> DyadicWideWord {
        DyadicWideWord {
            sign: self.signs[index],
            magnitude: self.numerator_magnitudes[index],
            denominator_shift: self.denominator_shifts[index],
        }
    }

    fn denominator(&self) -> DyadicWideWord {
        DyadicWideWord {
            sign: self.signs[2],
            magnitude: self.denominator_magnitude,
            denominator_shift: self.denominator_shifts[2],
        }
    }

    fn wide_word(value: DyadicWord) -> DyadicWideWord {
        DyadicWideWord {
            sign: value.sign,
            magnitude: [
                value.magnitude as u64,
                (value.magnitude >> 64) as u64,
                0,
                0,
            ],
            denominator_shift: value.denominator_shift,
        }
    }

    fn multiply_magnitudes(left: [u64; 4], right: [u64; 4]) -> [u64; 8] {
        let mut product = [0_u64; 8];
        for (left_index, left_limb) in left.into_iter().enumerate() {
            let mut carry = 0_u128;
            for (right_index, right_limb) in right.into_iter().enumerate() {
                let index = left_index + right_index;
                let total = u128::from(product[index])
                    + u128::from(left_limb) * u128::from(right_limb)
                    + carry;
                product[index] = total as u64;
                carry = total >> 64;
            }
            product[left_index + 4] = carry as u64;
        }
        product
    }

    fn shifted_product(product: [u64; 8], shift: u128) -> [u64; 16] {
        let word_shift = usize::try_from(shift / 64)
            .expect("bounded wide comparison shift fits usize");
        let bit_shift = u32::try_from(shift % 64).expect("limb bit shift fits u32");
        let mut shifted = [0_u64; 16];
        for (index, limb) in product.into_iter().enumerate() {
            if limb == 0 {
                continue;
            }
            shifted[word_shift + index] |= limb << bit_shift;
            if bit_shift != 0 {
                shifted[word_shift + index + 1] |= limb >> (64 - bit_shift);
            }
        }
        shifted
    }

    fn compare_parameter_words(
        left_numerator: DyadicWideWord,
        left_denominator: DyadicWideWord,
        right_numerator: DyadicWideWord,
        right_denominator: DyadicWideWord,
    ) -> Ordering {
        let left_sign = left_numerator.sign * left_denominator.sign;
        let right_sign = right_numerator.sign * right_denominator.sign;
        if left_sign != right_sign {
            return match (left_sign, right_sign) {
                (Minus, _) | (_, Plus) => Ordering::Less,
                (Plus, _) | (_, Minus) => Ordering::Greater,
                _ => Ordering::Equal,
            };
        }
        if left_sign == NoSign {
            return Ordering::Equal;
        }

        let left = Self::multiply_magnitudes(
            left_numerator.magnitude,
            right_denominator.magnitude,
        );
        let right = Self::multiply_magnitudes(
            right_numerator.magnitude,
            left_denominator.magnitude,
        );
        let bit_len = |value: &[u64; 8]| {
            let index = value
                .iter()
                .rposition(|limb| *limb != 0)
                .expect("nonzero parameter product has a nonzero limb");
            u128::try_from(index * 64 + (64 - value[index].leading_zeros() as usize))
                .expect("fixed product bit length fits u128")
        };
        let left_shift = u128::from(left_denominator.denominator_shift)
            + u128::from(right_numerator.denominator_shift);
        let right_shift = u128::from(right_denominator.denominator_shift)
            + u128::from(left_numerator.denominator_shift);
        let ordering = match (bit_len(&left) + left_shift).cmp(&(bit_len(&right) + right_shift)) {
            Ordering::Equal => {
                let common_shift = left_shift.min(right_shift);
                let left = Self::shifted_product(left, left_shift - common_shift);
                let right = Self::shifted_product(right, right_shift - common_shift);
                left.iter().rev().cmp(right.iter().rev())
            }
            ordering => ordering,
        };
        if left_sign == Minus {
            ordering.reverse()
        } else {
            ordering
        }
    }

    fn compare_parameter(&self, index: usize, other: &Self) -> Ordering {
        Self::compare_parameter_words(
            self.numerator(index),
            self.denominator(),
            other.numerator(index),
            other.denominator(),
        )
    }

    fn compare_parameter_to_compact(
        &self,
        index: usize,
        other: &ExactDyadicLineParameters2,
    ) -> Ordering {
        Self::compare_parameter_words(
            self.numerator(index),
            self.denominator(),
            Self::wide_word(other.numerator(index)),
            Self::wide_word(other.denominator()),
        )
    }

    /// Compare the parameter on the first source line without reducing it.
    pub fn compare_first_parameter(&self, other: &Self) -> Ordering {
        self.compare_parameter(0, other)
    }

    /// Compare the parameter on the second source line without reducing it.
    pub fn compare_second_parameter(&self, other: &Self) -> Ordering {
        self.compare_parameter(1, other)
    }

    /// Compare the first parameter with the native-word carrier.
    pub fn compare_first_parameter_to_compact(
        &self,
        other: &ExactDyadicLineParameters2,
    ) -> Ordering {
        self.compare_parameter_to_compact(0, other)
    }

    /// Compare the second parameter with the native-word carrier.
    pub fn compare_second_parameter_to_compact(
        &self,
        other: &ExactDyadicLineParameters2,
    ) -> Ordering {
        self.compare_parameter_to_compact(1, other)
    }

    pub(crate) fn materialize_parameter(&self, index: usize) -> Rational {
        Rational::quotient_dyadic_wide_words(
            self.numerator(index),
            self.denominator(),
            false,
        )
    }
}

impl DyadicStackAccumulator {
    /// Add a precomputed magnitude after binary alignment without building a
    /// second full-width stack value. Product bits occupy disjoint portions of
    /// adjacent shifted limbs; arithmetic carries are then propagated only as
    /// far as the occupied result requires.
    #[inline]
    fn add_shifted_limbs<const N: usize>(
        &mut self,
        product: [u64; N],
        shift: u64,
    ) -> Option<()> {
        let Some(last_source) = product.iter().rposition(|limb| *limb != 0) else {
            return Some(());
        };
        let word_shift = usize::try_from(shift / 64).ok()?;
        let bit_shift = u32::try_from(shift % 64).expect("limb bit shift fits u32");
        let has_high_limb =
            bit_shift != 0 && product[last_source] >> (64 - bit_shift) != 0;
        let last_offset = last_source + usize::from(has_high_limb);
        let last_target = word_shift.checked_add(last_offset)?;
        if last_target >= DYADIC_STACK_LIMBS {
            return None;
        }

        let mut carry = false;
        for offset in 0..=last_offset {
            let mut addend = product.get(offset).copied().unwrap_or(0) << bit_shift;
            if bit_shift != 0 && offset != 0 {
                addend |= product[offset - 1] >> (64 - bit_shift);
            }
            let target = word_shift + offset;
            let (sum, first_carry) = self.0[target].overflowing_add(addend);
            let (sum, second_carry) = sum.overflowing_add(u64::from(carry));
            self.0[target] = sum;
            carry = first_carry || second_carry;
        }

        let mut target = last_target + 1;
        while carry {
            if target == DYADIC_STACK_LIMBS {
                return None;
            }
            let (sum, next_carry) = self.0[target].overflowing_add(1);
            self.0[target] = sum;
            carry = next_carry;
            target += 1;
        }
        Some(())
    }

    fn add_product(&mut self, left: u128, right: u128, shift: u64) -> Option<()> {
        let left = [left as u64, (left >> 64) as u64];
        let right = [right as u64, (right >> 64) as u64];
        let mut product = [0_u64; 4];
        for (left_index, left_limb) in left.into_iter().enumerate() {
            let mut carry = 0_u128;
            for (right_index, right_limb) in right.into_iter().enumerate() {
                let index = left_index + right_index;
                let total = u128::from(product[index])
                    + u128::from(left_limb) * u128::from(right_limb)
                    + carry;
                product[index] = total as u64;
                carry = total >> 64;
            }
            let index = left_index + 2;
            let total = u128::from(product[index]) + carry;
            product[index] = total as u64;
            debug_assert_eq!(total >> 64, 0);
        }
        self.add_shifted_limbs(product, shift)
    }

    fn add_wide_word_product(
        &mut self,
        left: [u64; 4],
        right: u128,
        shift: u64,
    ) -> Option<()> {
        if let Ok(right) = u64::try_from(right) {
            let mut product = [0_u64; 5];
            let mut carry = 0_u128;
            for index in 0..4 {
                let total = u128::from(left[index]) * u128::from(right) + carry;
                product[index] = total as u64;
                carry = total >> 64;
            }
            product[4] = carry as u64;
            return self.add_shifted_limbs(product, shift);
        }
        let right = [right as u64, (right >> 64) as u64];
        let mut product = [0_u64; DYADIC_STACK_LIMBS];
        for (left_index, left_limb) in left.into_iter().enumerate() {
            let mut carry = 0_u128;
            for (right_index, right_limb) in right.into_iter().enumerate() {
                let index = left_index + right_index;
                let total = u128::from(product[index])
                    + u128::from(left_limb) * u128::from(right_limb)
                    + carry;
                product[index] = total as u64;
                carry = total >> 64;
            }
            let index = left_index + 2;
            let total = u128::from(product[index]) + carry;
            product[index] = total as u64;
            if total >> 64 != 0 {
                return None;
            }
        }
        self.add_shifted_limbs(product, shift)
    }

    fn difference(positive: Self, negative: Self) -> Option<(Sign, Self)> {
        let ordering = positive
            .0
            .iter()
            .rev()
            .cmp(negative.0.iter().rev());
        let (sign, larger, smaller) = match ordering {
            Ordering::Greater => (Plus, positive, negative),
            Ordering::Less => (Minus, negative, positive),
            Ordering::Equal => return None,
        };
        let mut result = Self::default();
        let mut borrow = false;
        for index in 0..DYADIC_STACK_LIMBS {
            let (value, first_borrow) = larger.0[index].overflowing_sub(smaller.0[index]);
            let (value, second_borrow) = value.overflowing_sub(u64::from(borrow));
            result.0[index] = value;
            borrow = first_borrow || second_borrow;
        }
        debug_assert!(!borrow);
        Some((sign, result))
    }

    fn trailing_zeros(&self) -> u64 {
        let (index, value) = self
            .0
            .iter()
            .copied()
            .enumerate()
            .find(|(_, value)| *value != 0)
            .expect("nonzero accumulator has a nonzero limb");
        u64::try_from(index * 64).expect("fixed accumulator width fits u64")
            + u64::from(value.trailing_zeros())
    }

    fn shift_right(&mut self, shift: u64) {
        let word_shift = usize::try_from(shift / 64).expect("bounded shift fits usize");
        let bit_shift = u32::try_from(shift % 64).expect("limb bit shift fits u32");
        if word_shift != 0 {
            self.0.copy_within(word_shift.., 0);
            self.0[DYADIC_STACK_LIMBS - word_shift..].fill(0);
        }
        if bit_shift != 0 {
            for index in 0..DYADIC_STACK_LIMBS {
                let high = self.0.get(index + 1).copied().unwrap_or(0);
                self.0[index] =
                    (self.0[index] >> bit_shift) | (high << (64 - bit_shift));
            }
        }
    }

    fn to_u128(self) -> Option<u128> {
        self.0[2..]
            .iter()
            .all(|value| *value == 0)
            .then(|| u128::from(self.0[0]) | (u128::from(self.0[1]) << 64))
    }

    fn into_biguint(self) -> BigUint {
        let last = self
            .0
            .iter()
            .rposition(|value| *value != 0)
            .expect("nonzero accumulator has a nonzero limb");
        let mut digits = Vec::with_capacity((last + 1) * 2);
        for limb in &self.0[..=last] {
            digits.push(*limb as u32);
            digits.push((*limb >> 32) as u32);
        }
        while digits.last() == Some(&0) {
            digits.pop();
        }
        BigUint::new(digits)
    }
}

impl Rational {
    fn exact_dyadic_f64_word(value: f64) -> Option<DyadicWord> {
        const SIGN_MASK: u64 = 1 << 63;
        const EXPONENT_MASK: u64 = 0x7ff0_0000_0000_0000;
        const SIGNIFICAND_MASK: u64 = 0x000f_ffff_ffff_ffff;
        const IMPLICIT_BIT: u64 = SIGNIFICAND_MASK + 1;

        let bits = value.to_bits();
        let exponent = (bits & EXPONENT_MASK) >> 52;
        let significand = bits & SIGNIFICAND_MASK;
        if exponent == 0x7ff {
            return None;
        }
        if exponent == 0 && significand == 0 {
            return Some(DyadicWord {
                sign: NoSign,
                magnitude: 0,
                denominator_shift: 0,
            });
        }
        let sign = if bits & SIGN_MASK == 0 { Plus } else { Minus };
        let (mut magnitude, mut denominator_shift) = if exponent == 0 {
            (u128::from(significand), 1074)
        } else if exponent <= 1075 {
            (u128::from(IMPLICIT_BIT + significand), 1075 - exponent)
        } else {
            let shift = u32::try_from(exponent - 1075).ok()?;
            (
                Self::checked_word_shift_left(u128::from(IMPLICIT_BIT + significand), shift)?,
                0,
            )
        };
        let common_shift = u64::from(magnitude.trailing_zeros()).min(denominator_shift);
        magnitude >>= common_shift;
        denominator_shift -= common_shift;
        Some(DyadicWord {
            sign,
            magnitude,
            denominator_shift,
        })
    }

    pub(crate) fn exact_dyadic_line2_from_rationals(
        start: [&Self; 2],
        end: [&Self; 2],
    ) -> Option<ExactDyadicLine2> {
        let point_words = |point: [&Self; 2]| {
            Some([
                Self::known_dyadic_word(point[0])?,
                Self::known_dyadic_word(point[1])?,
            ])
        };
        let start = point_words(start)?;
        let end = point_words(end)?;
        Some(ExactDyadicLine2 {
            start,
            delta: [
                Self::difference_dyadic_words(end[0], start[0])?,
                Self::difference_dyadic_words(end[1], start[1])?,
            ],
        })
    }

    pub(crate) fn exact_dyadic_line2_from_f64(
        start: [f64; 2],
        end: [f64; 2],
    ) -> Option<ExactDyadicLine2> {
        let point_words = |point: [f64; 2]| {
            Some([
                Self::exact_dyadic_f64_word(point[0])?,
                Self::exact_dyadic_f64_word(point[1])?,
            ])
        };
        let start = point_words(start)?;
        let end = point_words(end)?;
        Some(ExactDyadicLine2 {
            start,
            delta: [
                Self::difference_dyadic_words(end[0], start[0])?,
                Self::difference_dyadic_words(end[1], start[1])?,
            ],
        })
    }

    fn line_intersection2_plan_known_dyadic(
        first_start: [&Self; 2],
        first_end: [&Self; 2],
        second_start: [&Self; 2],
        second_end: [&Self; 2],
    ) -> Option<DyadicLineIntersectionPlan> {
        let first = Self::exact_dyadic_line2_from_rationals(first_start, first_end)?;
        Self::line_intersection2_plan_with_first_line(
            &first,
            second_start,
            second_end,
        )
    }

    fn line_intersection2_plan_with_first_line(
        first: &ExactDyadicLine2,
        second_start: [&Self; 2],
        second_end: [&Self; 2],
    ) -> Option<DyadicLineIntersectionPlan> {
        let point_words = |point: [&Self; 2]| {
            Some([
                Self::known_dyadic_word(point[0])?,
                Self::known_dyadic_word(point[1])?,
            ])
        };
        let second_start = point_words(second_start)?;
        let second_end = point_words(second_end)?;
        Self::line_intersection2_plan_with_first_line_words(first, second_start, second_end)
    }

    fn line_intersection2_plan_with_first_line_exact_dyadic_f64(
        first: &ExactDyadicLine2,
        second_start: [f64; 2],
        second_end: [f64; 2],
    ) -> Option<DyadicLineIntersectionPlan> {
        let point_words = |point: [f64; 2]| {
            Some([
                Self::exact_dyadic_f64_word(point[0])?,
                Self::exact_dyadic_f64_word(point[1])?,
            ])
        };
        Self::line_intersection2_plan_with_first_line_words(
            first,
            point_words(second_start)?,
            point_words(second_end)?,
        )
    }

    fn line_intersection2_plan_with_first_line_words(
        first: &ExactDyadicLine2,
        second_start: [DyadicWord; 2],
        second_end: [DyadicWord; 2],
    ) -> Option<DyadicLineIntersectionPlan> {
        let difference = |left: [DyadicWord; 2], right: [DyadicWord; 2]| {
            Some([
                Self::difference_dyadic_words(left[0], right[0])?,
                Self::difference_dyadic_words(left[1], right[1])?,
            ])
        };
        let second_delta = difference(second_end, second_start)?;
        let start_delta = difference(second_start, first.start)?;
        let cross = |left, right| {
            Self::cross_dyadic_words_word(left, right).or_else(|| {
                Self::cross_dyadic_words(left, right).and_then(Self::dyadic_stack_sum_word)
            })
        };
        let denominator = cross(first.delta, second_delta)?;
        if denominator.sign == NoSign {
            return None;
        }
        let first_numerator = cross(start_delta, second_delta)?;
        let second_numerator = cross(start_delta, first.delta)?;
        Some(DyadicLineIntersectionPlan {
            first_start: first.start,
            first_delta: first.delta,
            denominator,
            numerators: [first_numerator, second_numerator],
        })
    }

    fn line_intersection2_wide_plan_known_dyadic(
        first_start: [&Self; 2],
        first_end: [&Self; 2],
        second_start: [&Self; 2],
        second_end: [&Self; 2],
    ) -> Option<DyadicWideLineIntersectionPlan> {
        let first = Self::exact_dyadic_line2_from_rationals(first_start, first_end)?;
        Self::line_intersection2_wide_plan_with_first_line(
            &first,
            second_start,
            second_end,
        )
    }

    fn line_intersection2_wide_plan_with_first_line(
        first: &ExactDyadicLine2,
        second_start: [&Self; 2],
        second_end: [&Self; 2],
    ) -> Option<DyadicWideLineIntersectionPlan> {
        let point_words = |point: [&Self; 2]| {
            Some([
                Self::known_dyadic_word(point[0])?,
                Self::known_dyadic_word(point[1])?,
            ])
        };
        let second_start = point_words(second_start)?;
        let second_end = point_words(second_end)?;
        Self::line_intersection2_wide_plan_with_first_line_words(first, second_start, second_end)
    }

    fn line_intersection2_wide_plan_with_first_line_exact_dyadic_f64(
        first: &ExactDyadicLine2,
        second_start: [f64; 2],
        second_end: [f64; 2],
    ) -> Option<DyadicWideLineIntersectionPlan> {
        let point_words = |point: [f64; 2]| {
            Some([
                Self::exact_dyadic_f64_word(point[0])?,
                Self::exact_dyadic_f64_word(point[1])?,
            ])
        };
        Self::line_intersection2_wide_plan_with_first_line_words(
            first,
            point_words(second_start)?,
            point_words(second_end)?,
        )
    }

    fn line_intersection2_wide_plan_with_first_line_words(
        first: &ExactDyadicLine2,
        second_start: [DyadicWord; 2],
        second_end: [DyadicWord; 2],
    ) -> Option<DyadicWideLineIntersectionPlan> {
        let difference = |left: [DyadicWord; 2], right: [DyadicWord; 2]| {
            Some([
                Self::difference_dyadic_words(left[0], right[0])?,
                Self::difference_dyadic_words(left[1], right[1])?,
            ])
        };
        let second_delta = difference(second_end, second_start)?;
        let start_delta = difference(second_start, first.start)?;
        let denominator = Self::dyadic_stack_sum_wide_word(Self::cross_dyadic_words(
            first.delta,
            second_delta,
        )?)?;
        if denominator.sign == NoSign {
            return None;
        }
        let first_numerator = Self::dyadic_stack_sum_wide_word(Self::cross_dyadic_words(
            start_delta,
            second_delta,
        )?)?;
        let second_numerator = Self::dyadic_stack_sum_wide_word(Self::cross_dyadic_words(
            start_delta,
            first.delta,
        )?)?;
        Some(DyadicWideLineIntersectionPlan {
            first_start: first.start,
            first_delta: first.delta,
            denominator,
            numerators: [first_numerator, second_numerator],
        })
    }

    /// Use one full-width remainder when exactly one operand fits a native word.
    ///
    /// Word pairs stay in the native binary reducer. Mixed-width identity and
    /// power-of-two operands resolve structurally; other mixed-width values
    /// reduce the wide operand modulo the word once. Equal wide operands
    /// resolve directly. Wider balanced operands use the retained
    /// Euclidean/Lehmer reducer, avoiding `BigUint`'s subtraction-heavy binary
    /// GCD on exact-geometry rationals with thousands of bits.
    pub(crate) fn gcd_magnitudes_with_mixed_width_fast_path(
        left: &BigUint,
        right: &BigUint,
    ) -> BigUint {
        match (left.to_u128(), right.to_u128()) {
            (Some(left), Some(right)) => {
                crate::trace_dispatch!("rational_algorithm", "gcd", "binary-word");
                BigUint::from(Self::gcd_word(left, right))
            }
            (Some(0), None) => {
                crate::trace_dispatch!("rational_algorithm", "gcd", "identity-wide");
                right.clone()
            }
            (None, Some(0)) => {
                crate::trace_dispatch!("rational_algorithm", "gcd", "identity-wide");
                left.clone()
            }
            (Some(1), None) | (None, Some(1)) => {
                crate::trace_dispatch!("rational_algorithm", "gcd", "identity-wide");
                BigUint::one()
            }
            (Some(word), None) if word.is_power_of_two() => {
                crate::trace_dispatch!("rational_algorithm", "gcd", "power-of-two-wide");
                let common_shift = u64::from(word.trailing_zeros()).min(
                    right
                        .trailing_zeros()
                        .expect("nonzero BigUint has trailing zeros"),
                );
                BigUint::one() << common_shift
            }
            (None, Some(word)) if word.is_power_of_two() => {
                crate::trace_dispatch!("rational_algorithm", "gcd", "power-of-two-wide");
                let common_shift = u64::from(word.trailing_zeros()).min(
                    left.trailing_zeros()
                        .expect("nonzero BigUint has trailing zeros"),
                );
                BigUint::one() << common_shift
            }
            (Some(word), None) => {
                crate::trace_dispatch!("rational_algorithm", "gcd", "euclidean-wide-word");
                let remainder = (right % left)
                    .to_u128()
                    .expect("remainder is smaller than a u128 divisor");
                BigUint::from(Self::gcd_word(word, remainder))
            }
            (None, Some(word)) => {
                crate::trace_dispatch!("rational_algorithm", "gcd", "euclidean-wide-word");
                let remainder = (left % right)
                    .to_u128()
                    .expect("remainder is smaller than a u128 divisor");
                BigUint::from(Self::gcd_word(word, remainder))
            }
            (None, None) => {
                if left == right {
                    crate::trace_dispatch!("rational_algorithm", "gcd", "equal-wide");
                    return left.clone();
                }
                if Self::is_power_of_two(left) || Self::is_power_of_two(right) {
                    crate::trace_dispatch!("rational_algorithm", "gcd", "power-of-two-wide");
                    let common_shift = left
                        .trailing_zeros()
                        .expect("nonzero BigUint has trailing zeros")
                        .min(
                            right
                                .trailing_zeros()
                                .expect("nonzero BigUint has trailing zeros"),
                        );
                    return BigUint::one() << common_shift;
                }
                if let Some(divisor) = Self::gcd_fixed::<4>(left, right) {
                    crate::trace_dispatch!("rational_algorithm", "gcd", "binary-fixed-256");
                    return divisor;
                }
                if let Some(divisor) = Self::gcd_fixed::<8>(left, right) {
                    crate::trace_dispatch!("rational_algorithm", "gcd", "binary-fixed-512");
                    return divisor;
                }
                let (divisor, algorithm) = Self::gcd_wide_magnitudes(left, right, false);
                crate::trace_dispatch!("rational_algorithm", "gcd", algorithm);
                #[cfg(not(feature = "dispatch-trace"))]
                let _ = algorithm;
                divisor
            }
        }
    }

    // Tuned below after the Lehmer path is benchmarked against the full-width
    // Euclidean remainder loop. Keeping the boundary explicit lets the trace
    // and crossover tests describe the selected algorithm rather than merely
    // the operand size.
    const LEHMER_GCD_THRESHOLD_BITS: u64 = 192;
    const HALF_GCD_RECURSION_BASE_BITS: u64 = 1024;
    const HALF_GCD_THRESHOLD_BITS: u64 = 16_384;

    const POWERS_OF_FIVE: [u128; 56] = {
        let mut powers = [1_u128; 56];
        let mut index = 1;
        while index < powers.len() {
            powers[index] = powers[index - 1] * 5;
            index += 1;
        }
        powers
    };

    const SMALL_GCD_SIDE: usize = 64;
    const SMALL_GCD_TABLE: [u8; Self::SMALL_GCD_SIDE * Self::SMALL_GCD_SIDE] = {
        let mut table = [0_u8; Self::SMALL_GCD_SIDE * Self::SMALL_GCD_SIDE];
        let mut left = 0;
        while left < Self::SMALL_GCD_SIDE {
            let mut right = 0;
            while right < Self::SMALL_GCD_SIDE {
                let mut larger = left;
                let mut smaller = right;
                while smaller != 0 {
                    let remainder = larger % smaller;
                    larger = smaller;
                    smaller = remainder;
                }
                table[left * Self::SMALL_GCD_SIDE + right] = larger as u8;
                right += 1;
            }
            left += 1;
        }
        table
    };

    #[inline]
    fn gcd_u64(left: u64, right: u64) -> u64 {
        if left == 0 {
            return right;
        }
        if right == 0 {
            return left;
        }
        if left < Self::SMALL_GCD_SIDE as u64 && right < Self::SMALL_GCD_SIDE as u64 {
            let index = left as usize * Self::SMALL_GCD_SIDE + right as usize;
            return u64::from(Self::SMALL_GCD_TABLE[index]);
        }

        let common_shift = left.trailing_zeros().min(right.trailing_zeros());
        let mut left = left >> left.trailing_zeros();
        let mut right = right;
        loop {
            right >>= right.trailing_zeros();
            if left > right {
                std::mem::swap(&mut left, &mut right);
            }
            right -= left;
            if right == 0 {
                return left << common_shift;
            }
        }
    }

    /// Run binary GCD in a bounded stack buffer, falling through when either
    /// operand exceeds the selected limb tier.
    fn gcd_fixed<const WORDS: usize>(left: &BigUint, right: &BigUint) -> Option<BigUint> {
        debug_assert!(WORDS >= 2);
        let fixed = |value: &BigUint| {
            if value.bits() > u64::try_from(WORDS).expect("word count fits u64") * 64 {
                return None;
            }
            let mut words = [0_u64; WORDS];
            for (index, word) in value.iter_u64_digits().enumerate() {
                words[index] = word;
            }
            Some(words)
        };
        let mut left = fixed(left)?;
        let mut right = fixed(right)?;
        let trailing_zeros = |words: &[u64; WORDS]| {
            words
                .iter()
                .enumerate()
                .find_map(|(index, word)| {
                    (*word != 0).then_some(index as u32 * 64 + word.trailing_zeros())
                })
                .expect("wide gcd operands are nonzero")
        };
        let shift_right = |words: &mut [u64; WORDS], shift: u32| {
            let word_shift = usize::try_from(shift / 64).expect("word shift fits usize");
            let bit_shift = shift % 64;
            for index in 0..WORDS {
                let source = index + word_shift;
                words[index] = if source >= WORDS {
                    0
                } else if bit_shift == 0 {
                    words[source]
                } else {
                    (words[source] >> bit_shift)
                        | words.get(source + 1).copied().unwrap_or(0) << (64 - bit_shift)
                };
            }
        };
        let left_shift = trailing_zeros(&left);
        let right_shift = trailing_zeros(&right);
        let common_shift = left_shift.min(right_shift);
        shift_right(&mut left, left_shift);
        shift_right(&mut right, right_shift);
        loop {
            if left[2..].iter().all(|word| *word == 0)
                && right[2..].iter().all(|word| *word == 0)
            {
                let left = u128::from(left[0]) | u128::from(left[1]) << 64;
                let right = u128::from(right[0]) | u128::from(right[1]) << 64;
                return Some(BigUint::from(Self::gcd_word(left, right)) << common_shift);
            }
            let mut index = WORDS;
            let mut ordering = core::cmp::Ordering::Equal;
            while index != 0 {
                index -= 1;
                ordering = left[index].cmp(&right[index]);
                if !ordering.is_eq() {
                    break;
                }
            }
            if ordering.is_eq() {
                break;
            }
            // The three-way comparison makes the following difference
            // strictly positive, so the next normalization never sees zero.
            if ordering.is_gt() {
                core::mem::swap(&mut left, &mut right);
            }
            let mut borrow = false;
            for index in 0..WORDS {
                let (difference, first_borrow) = right[index].overflowing_sub(left[index]);
                let (difference, second_borrow) = difference.overflowing_sub(u64::from(borrow));
                right[index] = difference;
                borrow = first_borrow || second_borrow;
            }
            debug_assert!(!borrow);
            let right_shift = trailing_zeros(&right);
            shift_right(&mut right, right_shift);
        }

        if common_shift != 0 {
            let word_shift = usize::try_from(common_shift / 64).expect("word shift fits usize");
            let bit_shift = common_shift % 64;
            for index in (0..WORDS).rev() {
                left[index] = if index < word_shift {
                    0
                } else if bit_shift == 0 {
                    left[index - word_shift]
                } else {
                    (left[index - word_shift] << bit_shift)
                        | index
                            .checked_sub(word_shift + 1)
                            .map(|source| left[source] >> (64 - bit_shift))
                            .unwrap_or(0)
                };
            }
        }
        let digits = left
            .into_iter()
            .flat_map(|word| [word as u32, (word >> 32) as u32])
            .collect();
        Some(BigUint::new(digits))
    }

    fn gcd_word(left: u128, right: u128) -> u128 {
        if left == 0 {
            return right;
        }
        if right == 0 {
            return left;
        }
        if left <= u128::from(u64::MAX) && right <= u128::from(u64::MAX) {
            return u128::from(Self::gcd_u64(left as u64, right as u64));
        }
        if left <= u128::from(u64::MAX) {
            let left = left as u64;
            if left.is_power_of_two() {
                return 1_u128 << left.trailing_zeros().min(right.trailing_zeros());
            }
            return u128::from(Self::gcd_u64(left, (right % u128::from(left)) as u64));
        }
        if right <= u128::from(u64::MAX) {
            let right = right as u64;
            if right.is_power_of_two() {
                return 1_u128 << right.trailing_zeros().min(left.trailing_zeros());
            }
            return u128::from(Self::gcd_u64(right, (left % u128::from(right)) as u64));
        }

        // Balanced two-limb inputs reach a machine word after only a few
        // Euclidean steps. Stop there: u128 remainder is a compiler-rt call on
        // common 64-bit targets, while the remaining binary GCD stays entirely
        // in hardware-width arithmetic.
        let common_shift = left.trailing_zeros().min(right.trailing_zeros());
        let mut left = left >> common_shift;
        let mut right = right >> common_shift;
        if left < right {
            core::mem::swap(&mut left, &mut right);
        }
        while right > u128::from(u64::MAX) {
            // Consecutive Euclidean operands frequently have a small quotient.
            // Resolve the first four cases with subtraction: 128-bit remainder
            // is a compiler-runtime call on the 64-bit release targets we support.
            let difference = left - right;
            let remainder = if difference < right {
                difference
            } else {
                let second_difference = difference - right;
                if second_difference < right {
                    second_difference
                } else {
                    let third_difference = second_difference - right;
                    if third_difference < right {
                        third_difference
                    } else {
                        let fourth_difference = third_difference - right;
                        if fourth_difference < right {
                            fourth_difference
                        } else {
                            // Dividing the high limbs by a strict upper bound
                            // for the divisor yields a quotient that cannot
                            // overshoot. It usually leaves the exact remainder
                            // (or one divisor too much) without a compiler-rt
                            // 128-bit remainder call.
                            let high_quotient = ((left >> 64) as u64)
                                / (((right >> 64) as u64) + 1);
                            let approximate = left - right * u128::from(high_quotient);
                            if approximate < right {
                                approximate
                            } else {
                                let corrected = approximate - right;
                                if corrected < right {
                                    corrected
                                } else {
                                    corrected % right
                                }
                            }
                        }
                    }
                }
            };
            left = right;
            right = remainder;
        }
        if right == 0 {
            return left << common_shift;
        }
        let remainder = (left % right) as u64;
        u128::from(Self::gcd_u64(right as u64, remainder)) << common_shift
    }

    /// Compute an arbitrary-precision GCD without entering `BigUint`'s
    /// subtraction-heavy binary reducer for balanced wide operands.
    ///
    /// Exact binary-float matrix inversion repeatedly cross-cancels a dyadic
    /// cofactor numerator against the same odd determinant. Those operands are
    /// commonly only two or three machine words wide, where Euclidean
    /// remainder steps are substantially cheaper than long runs of shifts and
    /// subtractions. Preserve the tuned binary reducer for values that fit the
    /// scalar word path, and reduce a wide/small pair to that path after one
    /// remainder.
    fn lehmer_gcd_matrix(larger: &BigUint, smaller: &BigUint) -> Option<[i128; 4]> {
        debug_assert!(larger >= smaller);
        let shift = larger.bits().saturating_sub(62);
        let mut high_larger = (larger >> usize::try_from(shift).ok()?).to_i128()?;
        let mut high_smaller = (smaller >> usize::try_from(shift).ok()?).to_i128()?;
        if high_smaller == 0 {
            return None;
        }

        // The matrix maps the original pair to consecutive Euclidean
        // remainders. Two quotient estimates must agree at both interval
        // endpoints before a step is retained; this is Lehmer's guard against
        // a quotient depending on the discarded low limbs.
        let (mut a, mut b, mut c, mut d) = (1_i128, 0_i128, 0_i128, 1_i128);
        let mut steps = 0_u8;
        while let Some(numerator_low) = high_larger.checked_add(a) {
            let Some(numerator_high) = high_larger.checked_add(b) else {
                break;
            };
            let Some(denominator_low) = high_smaller.checked_add(c) else {
                break;
            };
            let Some(denominator_high) = high_smaller.checked_add(d) else {
                break;
            };
            if numerator_low < 0
                || numerator_high < 0
                || denominator_low <= 0
                || denominator_high <= 0
            {
                break;
            }
            let quotient = numerator_low / denominator_low;
            if quotient == 0 || quotient != numerator_high / denominator_high {
                break;
            }

            let Some(next_c) = a.checked_sub(quotient.checked_mul(c)?) else {
                break;
            };
            let Some(next_d) = b.checked_sub(quotient.checked_mul(d)?) else {
                break;
            };
            let Some(next_high_smaller) =
                high_larger.checked_sub(quotient.checked_mul(high_smaller)?)
            else {
                break;
            };
            if next_high_smaller < 0 {
                break;
            }

            // Scalar multiplication by coefficients larger than one machine
            // word loses the property that makes a Lehmer batch cheap.
            if [c, d, next_c, next_d]
                .into_iter()
                .any(|value| value.unsigned_abs() > u128::from(u64::MAX))
            {
                break;
            }

            (a, b, c, d) = (c, d, next_c, next_d);
            (high_larger, high_smaller) = (high_smaller, next_high_smaller);
            steps += 1;
        }

        (steps >= 2).then_some([a, b, c, d])
    }

    fn apply_lehmer_gcd_matrix(
        larger: &BigUint,
        smaller: &BigUint,
        [a, b, c, d]: [i128; 4],
    ) -> Option<(BigUint, BigUint)> {
        // Apply signed one-word coefficients without cloning wide values into
        // `BigInt`; a row magnitude is a sum or an absolute difference.
        let apply_row = |left: i128, right: i128| {
            let left_coefficient = u64::try_from(left.unsigned_abs()).ok()?;
            let right_coefficient = u64::try_from(right.unsigned_abs()).ok()?;
            let mut left_product = larger * left_coefficient;
            let right_product = smaller * right_coefficient;
            if left.is_negative() == right.is_negative() {
                left_product += right_product;
                Some(left_product)
            } else if left_product >= right_product {
                Some(left_product - right_product)
            } else {
                Some(right_product - left_product)
            }
        };
        let first = apply_row(a, b)?;
        let second = apply_row(c, d)?;
        if &first >= larger || &second >= larger {
            return None;
        }
        Some((first, second))
    }

    fn magnitude_difference_bits(left: &BigUint, right: &BigUint) -> u64 {
        if left >= right {
            (left - right).bits()
        } else {
            (right - left).bits()
        }
    }

    fn half_gcd_sdiv_step(
        left: &mut BigUint,
        right: &mut BigUint,
        stop_bits: u64,
        matrix: &mut HalfGcdMatrix,
    ) -> Option<()> {
        if left == right {
            return None;
        }
        if left > right {
            let mut quotient = &*left / &*right;
            let mut remainder = &*left
                - Self::multiply_magnitudes("half-gcd-sdiv-product", &quotient, right);
            if remainder.bits() <= stop_bits {
                quotient -= 1_u8;
                remainder += &*right;
            }
            if quotient.is_zero() || remainder >= *left {
                return None;
            }
            *left = remainder;
            matrix.update_right_column(&quotient);
        } else {
            let mut quotient = &*right / &*left;
            let mut remainder = &*right
                - Self::multiply_magnitudes("half-gcd-sdiv-product", &quotient, left);
            if remainder.bits() <= stop_bits {
                quotient -= 1_u8;
                remainder += &*left;
            }
            if quotient.is_zero() || remainder >= *right {
                return None;
            }
            *right = remainder;
            matrix.update_left_column(&quotient);
        }
        Some(())
    }

    fn half_gcd_slow(left: &BigUint, right: &BigUint) -> Option<HalfGcdReduction> {
        let stop_bits = left.bits().max(right.bits()) / 2 + 1;
        let mut left = left.clone();
        let mut right = right.clone();
        let mut matrix = HalfGcdMatrix::identity();
        while Self::magnitude_difference_bits(&left, &right) > stop_bits {
            Self::half_gcd_sdiv_step(&mut left, &mut right, stop_bits, &mut matrix)?;
        }
        Some(HalfGcdReduction {
            left,
            right,
            matrix,
        })
    }

    fn half_gcd_reduce(left: &BigUint, right: &BigUint) -> Option<HalfGcdReduction> {
        let input_bits = left.bits().max(right.bits());
        if input_bits <= Self::HALF_GCD_RECURSION_BASE_BITS {
            return Self::half_gcd_slow(left, right);
        }

        let stop_bits = input_bits / 2 + 1;
        let three_quarter_bits = input_bits.saturating_mul(3) / 4;
        let first_shift = input_bits / 2;
        let first_shift_usize = usize::try_from(first_shift).ok()?;
        let high_left = left >> first_shift_usize;
        let high_right = right >> first_shift_usize;
        let first = Self::half_gcd_reduce(&high_left, &high_right)?;
        let mut matrix = first.matrix;
        let (mut reduced_left, mut reduced_right) = matrix.apply_inverse(left, right)?;

        while reduced_left.bits().max(reduced_right.bits()) > three_quarter_bits + 1
            && Self::magnitude_difference_bits(&reduced_left, &reduced_right) > stop_bits
        {
            Self::half_gcd_sdiv_step(
                &mut reduced_left,
                &mut reduced_right,
                stop_bits,
                &mut matrix,
            )?;
        }

        let reduced_bits = reduced_left.bits().max(reduced_right.bits());
        if reduced_bits > stop_bits + 2 {
            let second_shift = stop_bits
                .saturating_mul(2)
                .checked_sub(reduced_bits)?
                .checked_add(1)?;
            if second_shift == 0 {
                return Self::half_gcd_slow(left, right);
            }
            let second_shift_usize = usize::try_from(second_shift).ok()?;
            let high_left = &reduced_left >> second_shift_usize;
            let high_right = &reduced_right >> second_shift_usize;
            if high_left.bits().max(high_right.bits()) >= input_bits {
                return Self::half_gcd_slow(left, right);
            }
            let second = Self::half_gcd_reduce(&high_left, &high_right)?;
            let (next_left, next_right) = second
                .matrix
                .apply_inverse(&reduced_left, &reduced_right)?;
            reduced_left = next_left;
            reduced_right = next_right;
            matrix.multiply_right(&second.matrix);
        }

        while Self::magnitude_difference_bits(&reduced_left, &reduced_right) > stop_bits {
            Self::half_gcd_sdiv_step(
                &mut reduced_left,
                &mut reduced_right,
                stop_bits,
                &mut matrix,
            )?;
        }
        Some(HalfGcdReduction {
            left: reduced_left,
            right: reduced_right,
            matrix,
        })
    }

    /// Exact magnitude GCD used by rational cross-cancellation.
    ///
    /// This is public only so the benchmark harness can compare the selected
    /// implementation with an otherwise identical full-width Euclidean loop.
    #[doc(hidden)]
    pub fn gcd_magnitudes(left: &BigUint, right: &BigUint) -> BigUint {
        let (divisor, algorithm) = if left.is_zero() {
            (right.clone(), "binary-word")
        } else if right.is_zero() {
            (left.clone(), "binary-word")
        } else if let (Some(left), Some(right)) = (left.to_u128(), right.to_u128()) {
            (
                BigUint::from(Self::gcd_word(left, right)),
                "binary-word",
            )
        } else {
            Self::gcd_wide_magnitudes(left, right, false)
        };

        #[cfg(feature = "dispatch-trace")]
        {
            crate::trace_dispatch!("rational_algorithm", "gcd", algorithm);
            crate::dispatch_trace::record_rational_gcd(left, right, &divisor);
        }
        #[cfg(not(feature = "dispatch-trace"))]
        let _ = algorithm;
        divisor
    }

    /// Quadratic Lehmer baseline retained for paired half-GCD benchmarks.
    #[doc(hidden)]
    pub fn gcd_magnitudes_lehmer_baseline(left: &BigUint, right: &BigUint) -> BigUint {
        if left.is_zero() {
            return right.clone();
        }
        if right.is_zero() {
            return left.clone();
        }
        if let (Some(left), Some(right)) = (left.to_u128(), right.to_u128()) {
            return BigUint::from(Self::gcd_word(left, right));
        }
        Self::gcd_wide_magnitudes(left, right, false).0
    }

    /// Recursive Möller half-GCD candidate retained for benchmark comparison.
    #[doc(hidden)]
    pub fn gcd_magnitudes_half_gcd_candidate(left: &BigUint, right: &BigUint) -> BigUint {
        if left.is_zero() {
            return right.clone();
        }
        if right.is_zero() {
            return left.clone();
        }
        if let (Some(left), Some(right)) = (left.to_u128(), right.to_u128()) {
            return BigUint::from(Self::gcd_word(left, right));
        }
        let (divisor, algorithm) = Self::gcd_wide_magnitudes(left, right, true);
        #[cfg(feature = "dispatch-trace")]
        {
            crate::trace_dispatch!("rational_algorithm", "gcd", algorithm);
            crate::dispatch_trace::record_rational_gcd(left, right, &divisor);
        }
        #[cfg(not(feature = "dispatch-trace"))]
        let _ = algorithm;
        divisor
    }

    fn gcd_wide_magnitudes(
        left: &BigUint,
        right: &BigUint,
        half_gcd_enabled: bool,
    ) -> (BigUint, &'static str) {

        let (larger, smaller) = if left >= right {
            (left, right)
        } else {
            (right, left)
        };
        if let Some(smaller_word) = smaller.to_u128() {
            let remainder = (larger % smaller)
                .to_u128()
                .expect("remainder is smaller than a u128 divisor");
            return (
                BigUint::from(Self::gcd_word(smaller_word, remainder)),
                "euclidean-wide-word",
            );
        }

        let mut larger = larger.clone();
        let mut smaller = smaller.clone();
        let mut used_half_gcd = false;
        while half_gcd_enabled
            && smaller.bits() >= Self::HALF_GCD_THRESHOLD_BITS
            && larger.bits().abs_diff(smaller.bits()) <= 1
        {
            let before_bits = larger.bits().max(smaller.bits());
            let Some(reduction) = Self::half_gcd_reduce(&larger, &smaller) else {
                break;
            };
            let (mut first, mut second) = (reduction.left, reduction.right);
            if first == second {
                return (first, "recursive-half-gcd");
            }
            if first > second {
                first -= &second;
            } else {
                second -= &first;
            }
            (larger, smaller) = if first >= second {
                (first, second)
            } else {
                (second, first)
            };
            if larger.bits().max(smaller.bits()) >= before_bits {
                break;
            }
            used_half_gcd = true;
        }
        let mut lehmer_selected = smaller.bits() >= Self::LEHMER_GCD_THRESHOLD_BITS;
        if lehmer_selected && larger.bits().abs_diff(smaller.bits()) > 1 {
            let remainder = &larger % &smaller;
            larger = smaller;
            smaller = remainder;
            lehmer_selected = smaller.bits() >= Self::LEHMER_GCD_THRESHOLD_BITS
                && larger.bits().abs_diff(smaller.bits()) <= 1;
        }
        let mut used_lehmer = false;
        while !smaller.is_zero() {
            if lehmer_selected
                && smaller.bits() > 128
                && larger.bits().abs_diff(smaller.bits()) <= 1
                && let Some(matrix) = Self::lehmer_gcd_matrix(&larger, &smaller)
                && let Some((first, second)) =
                    Self::apply_lehmer_gcd_matrix(&larger, &smaller, matrix)
            {
                used_lehmer = true;
                (larger, smaller) = if first >= second {
                    (first, second)
                } else {
                    (second, first)
                };
                continue;
            }
            let remainder = &larger % &smaller;
            larger = smaller;
            smaller = remainder;
        }
        (
            larger,
            if used_half_gcd {
                "recursive-half-gcd"
            } else if used_lehmer {
                "lehmer-leading-limb"
            } else {
                "euclidean-wide-remainder"
            },
        )
    }

    /// Multiply a set of rationals by one positive common denominator.
    ///
    /// Every returned value is an integer and the same positive scale is
    /// applied to every input. This is useful for projective coordinates and
    /// polynomial coefficients whose common nonzero scale is immaterial.
    ///
    /// An empty input produces an empty output.
    pub fn clear_common_denominator_slice(values: &[&Self]) -> Vec<Self> {
        if values.is_empty() {
            return Vec::new();
        }
        let common_denominator = Self::common_denominator(values);
        crate::trace_dispatch!("rational", "common-scale", "clear-denominator-slice");
        values
            .iter()
            .map(|value| {
                if value.sign == NoSign {
                    return Self::zero();
                }
                let scale = &common_denominator / &value.denominator;
                Self::from_integer_magnitude(value.sign, &value.numerator * scale)
            })
            .collect()
    }

    /// Returns the positive integer greatest common divisor of the reduced
    /// numerator magnitudes of two rationals.
    ///
    /// Denominators and signs deliberately do not participate. This exposes
    /// the reusable integer content needed to schedule projective and affine
    /// exact-coordinate normalization without cloning numerator internals in
    /// downstream geometry crates. Zero is the identity, as for integer GCD.
    pub fn numerator_magnitude_gcd(&self, other: &Self) -> Self {
        let left = self.canonicalized_ref();
        let right = other.canonicalized_ref();
        Self::from_unsigned_integer(Self::gcd_magnitudes_with_mixed_width_fast_path(
            &left.numerator,
            &right.numerator,
        ))
    }

    /// Returns the reduced unsigned numerator magnitude of `self - other`
    /// when both operands are exact dyadics.
    ///
    /// This structural query deliberately bypasses retained linear-result
    /// scheduling. It is intended for one-shot representation analysis where
    /// populating an operand's bounded arithmetic cache would displace work
    /// that a subsequent numeric kernel actually reuses.
    pub fn dyadic_difference_numerator_magnitude(&self, other: &Self) -> Option<Self> {
        let left = self.canonicalized_ref();
        let right = other.canonicalized_ref();
        let left_shift = Self::biguint_power_of_two_shift(&left.denominator)?;
        let right_shift = Self::biguint_power_of_two_shift(&right.denominator)?;
        let denominator_shift = left_shift.max(right_shift);
        let left_scale = usize::try_from(denominator_shift - left_shift).ok()?;
        let right_scale = usize::try_from(denominator_shift - right_shift).ok()?;
        let left_magnitude = &left.numerator << left_scale;
        let right_magnitude = &right.numerator << right_scale;
        let mut magnitude = match (left.sign, right.sign) {
            (NoSign, NoSign) => return Some(Self::zero()),
            (NoSign, _) => right_magnitude,
            (_, NoSign) => left_magnitude,
            (left_sign, right_sign) if left_sign != right_sign => {
                left_magnitude + right_magnitude
            }
            _ => match left_magnitude.cmp(&right_magnitude) {
                Ordering::Less => right_magnitude - left_magnitude,
                Ordering::Equal => return Some(Self::zero()),
                Ordering::Greater => left_magnitude - right_magnitude,
            },
        };
        let reduction_shift = magnitude
            .trailing_zeros()
            .expect("nonzero magnitude has trailing zeros")
            .min(denominator_shift);
        magnitude >>= usize::try_from(reduction_shift).ok()?;
        Some(Self::from_unsigned_integer(magnitude))
    }

    /// Normalize a fixed exact-rational ratio to primitive integer components.
    ///
    /// The returned array differs from the input by one positive common
    /// scale: denominators are cleared and the greatest common magnitude of
    /// all nonzero integer components is removed. Empty and all-zero inputs
    /// preserve their shape; a single nonzero component becomes its signed
    /// unit without allocating a common denominator.
    pub fn primitive_integer_ratio<const N: usize>(values: [&Self; N]) -> [Self; N] {
        let mut single = None;
        let mut multiple = false;
        for (index, value) in values.iter().enumerate() {
            if value.sign == NoSign {
                continue;
            }
            if single.is_some() {
                multiple = true;
                break;
            }
            single = Some((index, value.sign));
        }
        if !multiple {
            let Some((single_index, single_sign)) = single else {
                return values.map(|_| Self::zero());
            };
            return core::array::from_fn(|index| {
                if index == single_index {
                    Self::from_integer_magnitude(single_sign, BigUint::one())
                } else {
                    Self::zero()
                }
            });
        }
        let common_denominator = Self::common_denominator(&values);
        let mut integers = values.map(|value| {
            if value.sign == NoSign {
                return Self::zero();
            }
            let scale = &common_denominator / &value.denominator;
            Self::from_integer_magnitude(value.sign, &value.numerator * scale)
        });
        let mut content = BigUint::ZERO;
        for value in &integers {
            if value.sign == NoSign {
                continue;
            }
            content = if content.is_zero() {
                value.numerator.clone()
            } else {
                Self::gcd_magnitudes_with_mixed_width_fast_path(&content, &value.numerator)
            };
            if content.is_one() {
                return integers;
            }
        }
        if content.is_zero() || content.is_one() {
            return integers;
        }
        for value in &mut integers {
            if value.sign != NoSign {
                *value =
                    Self::from_integer_magnitude(value.sign, &value.numerator / &content);
            }
        }
        crate::trace_dispatch!("rational", "common-scale", "primitive-integer-ratio");
        integers
    }

    /// Normalize an exact-rational ratio directly to primitive big integers.
    ///
    /// This has the same positive projective scale as
    /// [`Self::primitive_integer_ratio`], but avoids constructing temporary
    /// [`Rational`] wrappers when an integer polynomial or elimination kernel
    /// immediately needs mutable [`BigInt`] coefficients.
    pub fn primitive_bigint_ratio(values: &[&Self]) -> Vec<BigInt> {
        if values.is_empty() {
            return Vec::new();
        }
        let common_denominator = Self::common_denominator(values);
        crate::trace_dispatch!("rational", "common-scale", "primitive-bigint-ratio");
        let mut integers = values
            .iter()
            .map(|value| {
                if value.sign == NoSign {
                    return BigInt::ZERO;
                }
                let scale = &common_denominator / &value.denominator;
                BigInt::from_biguint(value.sign, &value.numerator * scale)
            })
            .collect::<Vec<_>>();

        let mut content = BigUint::ZERO;
        for value in &integers {
            if value.is_zero() {
                continue;
            }
            content = if content.is_zero() {
                value.magnitude().clone()
            } else {
                Self::gcd_magnitudes_with_mixed_width_fast_path(&content, value.magnitude())
            };
            if content.is_one() {
                return integers;
            }
        }
        if content.is_zero() || content.is_one() {
            return integers;
        }
        let content = BigInt::from_biguint(Plus, content);
        for value in &mut integers {
            if !value.is_zero() {
                *value /= &content;
            }
        }
        integers
    }

    /// Multiply a fixed set of rationals by one positive common denominator.
    ///
    /// Vector normalization is invariant under this shared scale. Clearing it
    /// before the self-dot prevents the common denominator from passing through
    /// square extraction, reciprocal construction, and every output lane.
    pub(crate) fn clear_common_denominator<const N: usize>(values: [&Self; N]) -> [Self; N] {
        let common_denominator = Self::common_denominator(&values);

        crate::trace_dispatch!("rational", "common-scale", "clear-denominator");
        core::array::from_fn(|index| {
            let value = values[index];
            if value.sign == NoSign {
                return Self::zero();
            }
            let scale = &common_denominator / &value.denominator;
            Self::from_integer_magnitude(value.sign, &value.numerator * scale)
        })
    }

    fn common_denominator(values: &[&Self]) -> BigUint {
        debug_assert!(!values.is_empty());
        if values
            .iter()
            .all(|value| value.denominator == values[0].denominator)
        {
            values[0].denominator.clone()
        } else if values
            .iter()
            .all(|value| Self::is_power_of_two(&value.denominator))
        {
            values
                .iter()
                .max_by_key(|value| value.denominator.bits())
                .expect("fixed rational set is nonempty")
                .denominator
                .clone()
        } else {
            values.iter().skip(1).fold(
                values[0].denominator.clone(),
                |common, value| {
                    let divisor = Self::gcd_magnitudes(&common, &value.denominator);
                    (common / divisor) * &value.denominator
                },
            )
        }
    }

    fn from_word_magnitude_difference(
        positive: u128,
        negative: u128,
        denominator: u128,
    ) -> Self {
        let (sign, magnitude) = match positive.cmp(&negative) {
            Ordering::Greater => (Plus, positive - negative),
            Ordering::Less => (Minus, negative - positive),
            Ordering::Equal => {
                crate::trace_dispatch!("rational", "word-result", "zero");
                return Self::zero();
            }
        };
        if denominator.is_power_of_two() {
            let common_shift = magnitude.trailing_zeros().min(denominator.trailing_zeros());
            return Self::from_reduced_word_parts(
                sign,
                magnitude >> common_shift,
                denominator >> common_shift,
            );
        }

        let common_shift = magnitude.trailing_zeros().min(denominator.trailing_zeros());
        let mut magnitude = magnitude >> common_shift;
        let mut denominator = denominator >> common_shift;
        let odd_denominator = denominator >> denominator.trailing_zeros();
        if Self::POWERS_OF_FIVE
            .binary_search(&odd_denominator)
            .is_ok()
        {
            crate::trace_dispatch!("rational", "word-reduction", "power-of-five-denominator");
            while denominator.is_multiple_of(5) && magnitude.is_multiple_of(5) {
                denominator /= 5;
                magnitude /= 5;
            }
        } else {
            #[cfg(feature = "dispatch-trace")]
            {
                let path = if word_is_power_of(odd_denominator, 3) {
                    "power-of-three-denominator"
                } else if word_is_power_of(odd_denominator, 7) {
                    "power-of-seven-denominator"
                } else if word_is_smooth_357(odd_denominator) {
                    "mixed-357-smooth-denominator"
                } else if odd_denominator <= u128::from(u16::MAX) {
                    "other-small-odd-denominator"
                } else if odd_denominator <= u128::from(u64::MAX) {
                    "other-word-odd-denominator"
                } else {
                    "other-wide-odd-denominator"
                };
                crate::trace_dispatch!("rational", "word-reduction", path);
            }
            let divisor = Self::gcd_word(magnitude, denominator);
            magnitude /= divisor;
            denominator /= divisor;
        }
        Self::from_reduced_word_parts(sign, magnitude, denominator)
    }

    fn from_reduced_word_parts(sign: Sign, magnitude: u128, denominator: u128) -> Self {
        debug_assert_ne!(sign, NoSign);
        debug_assert_ne!(magnitude, 0);
        debug_assert_ne!(denominator, 0);
        if magnitude == denominator {
            crate::trace_dispatch!("rational", "word-result", "unit");
            return if sign == Minus {
                Self::minus_one()
            } else {
                Self::one()
            };
        }
        if denominator == 1 {
            if let Some(value) = Self::small_integer(sign, magnitude) {
                crate::trace_dispatch!("rational", "word-result", "cached-small-integer");
                return value;
            }
            #[cfg(feature = "dispatch-trace")]
            {
                let path = match magnitude {
                    0..=127 => "uncached-integer-65-127",
                    128..=255 => "uncached-integer-128-255",
                    256..=1023 => "uncached-integer-256-1023",
                    1024..=4095 => "uncached-integer-1024-4095",
                    _ => "uncached-integer-wide",
                };
                crate::trace_dispatch!("rational", "word-result", path);
            }
        } else if denominator.is_power_of_two() {
            if let Some(value) = Self::small_reduced_dyadic(sign, magnitude, denominator) {
                crate::trace_dispatch!("rational", "word-result", "cached-small-dyadic");
                return value;
            }
            crate::trace_dispatch!("rational", "word-result", "dyadic-fraction");
        } else {
            if let Some(value) =
                Self::small_reduced_general_fraction(sign, magnitude, denominator)
            {
                crate::trace_dispatch!("rational", "word-result", "cached-small-general-fraction");
                return value;
            }
            if magnitude <= u128::from(u64::MAX) && denominator <= u128::from(u64::MAX) {
                crate::trace_dispatch!("rational", "word-result", "small-general-fraction");
            } else {
                crate::trace_dispatch!("rational", "word-result", "wide-general-fraction");
            }
        }
        Self::from_parts_raw(
            sign,
            Self::biguint_from_word(magnitude),
            Self::biguint_from_word(denominator),
        )
    }

    #[inline]
    fn biguint_from_word(value: u128) -> BigUint {
        if let Ok(value) = u64::try_from(value) {
            BigUint::from(value)
        } else {
            BigUint::from(value)
        }
    }

    fn product_term_words<const FACTORS: usize>(
        term: [&Self; FACTORS],
    ) -> Option<(u128, u128)> {
        let mut magnitude = 1_u128;
        let mut denominator = 1_u128;
        for factor in term {
            let numerator = factor.numerator.to_u128()?;
            let factor_denominator = factor.denominator.to_u128()?;
            let Some(next_magnitude) = magnitude.checked_mul(numerator) else {
                return Self::product_term_words_cross_cancelled(term);
            };
            let Some(next_denominator) = denominator.checked_mul(factor_denominator) else {
                return Self::product_term_words_cross_cancelled(term);
            };
            magnitude = next_magnitude;
            denominator = next_denominator;
        }
        Some((magnitude, denominator))
    }

    fn product_term_words_cross_cancelled<const FACTORS: usize>(
        term: [&Self; FACTORS],
    ) -> Option<(u128, u128)> {
        let mut numerators = [0_u128; FACTORS];
        let mut denominators = [1_u128; FACTORS];
        for i in 0..FACTORS {
            numerators[i] = term[i].numerator.to_u128()?;
            denominators[i] = term[i].denominator.to_u128()?;
        }

        for numerator in &mut numerators {
            if *numerator == 1 {
                continue;
            }
            for denominator in &mut denominators {
                if *denominator == 1 {
                    continue;
                }
                let divisor = Self::gcd_word(*numerator, *denominator);
                *numerator /= divisor;
                *denominator /= divisor;
                if *numerator == 1 {
                    break;
                }
            }
        }

        let mut magnitude = 1_u128;
        let mut denominator = 1_u128;
        for factor in numerators {
            magnitude = magnitude.checked_mul(factor)?;
        }
        for factor in denominators {
            denominator = denominator.checked_mul(factor)?;
        }
        Some((magnitude, denominator))
    }

    fn signed_product_sum_words<const TERMS: usize, const FACTORS: usize>(
        terms: [[&Self; FACTORS]; TERMS],
        signs: [Sign; TERMS],
    ) -> Option<Self> {
        let (positive, negative, common_denominator) =
            Self::signed_product_sum_word_totals(terms, signs)?;
        Some(Self::from_word_magnitude_difference(
            positive,
            negative,
            common_denominator,
        ))
    }

    fn signed_product_sum_word_totals<const TERMS: usize, const FACTORS: usize>(
        terms: [[&Self; FACTORS]; TERMS],
        signs: [Sign; TERMS],
    ) -> Option<(u128, u128, u128)> {
        let mut magnitudes = [0_u128; TERMS];
        let mut denominators = [1_u128; TERMS];
        let mut common_denominator = None::<u128>;
        for i in 0..TERMS {
            if signs[i] == NoSign {
                continue;
            }
            let (magnitude, denominator) = Self::product_term_words(terms[i])?;
            magnitudes[i] = magnitude;
            denominators[i] = denominator;
            common_denominator = Some(match common_denominator {
                None => denominator,
                Some(common) if common == denominator => common,
                Some(common) => {
                    let divisor = Self::gcd_word(common, denominator);
                    common.checked_mul(denominator / divisor)?
                }
            });
        }

        let common_denominator = common_denominator.unwrap_or(1);

        let mut positive = 0_u128;
        let mut negative = 0_u128;
        for i in 0..TERMS {
            let sign = signs[i];
            if sign == NoSign {
                continue;
            }
            let magnitude = magnitudes[i]
                .checked_mul(common_denominator / denominators[i])?;
            match sign {
                Plus => positive = positive.checked_add(magnitude)?,
                Minus => negative = negative.checked_add(magnitude)?,
                NoSign => {}
            }
        }
        Some((positive, negative, common_denominator))
    }

    pub(crate) fn dominant_affine_cross_axis_words(
        a: [&Self; 3],
        b: [&Self; 3],
        c: [&Self; 3],
    ) -> Option<(usize, Sign)> {
        type Word = (Sign, u128, u128);

        fn words(values: [&Rational; 3]) -> Option<[Word; 3]> {
            let word = |value: &Rational| {
                Some((
                    value.sign,
                    value.numerator.to_u128()?,
                    value.denominator.to_u128()?,
                ))
            };
            Some([word(values[0])?, word(values[1])?, word(values[2])?])
        }

        fn difference(left: Word, right: Word) -> Option<Word> {
            let (left_scale, right_scale, denominator) = if left.2 == right.2 {
                (1, 1, left.2)
            } else {
                let divisor = Rational::gcd_word(left.2, right.2);
                let left_scale = right.2 / divisor;
                (left_scale, left.2 / divisor, left.2.checked_mul(left_scale)?)
            };
            let left = (left.0, left.1.checked_mul(left_scale)?);
            let right = (-right.0, right.1.checked_mul(right_scale)?);
            let (sign, magnitude) = Rational::signed_word_sum(left, right)?;
            if sign == NoSign {
                return Some((NoSign, 0, 1));
            }
            let divisor = Rational::gcd_word(magnitude, denominator);
            Some((sign, magnitude / divisor, denominator / divisor))
        }

        fn component(ab: [Word; 3], ac: [Word; 3], first: usize, second: usize) -> Option<(u128, u128, u128)> {
            let products = [
                Rational::word_product(ab[first], ac[second], true)?,
                Rational::word_product(ab[second], ac[first], false)?,
            ];
            let common_denominator = if products[0].2 == products[1].2 {
                products[0].2
            } else {
                let divisor = Rational::gcd_word(products[0].2, products[1].2);
                products[0]
                    .2
                    .checked_mul(products[1].2 / divisor)?
            };
            let mut positive = 0_u128;
            let mut negative = 0_u128;
            for (sign, magnitude, denominator) in products {
                let magnitude = magnitude.checked_mul(common_denominator / denominator)?;
                match sign {
                    Plus => positive = positive.checked_add(magnitude)?,
                    Minus => negative = negative.checked_add(magnitude)?,
                    NoSign => {},
                }
            }
            Some((positive, negative, common_denominator))
        }

        fn reduced_magnitude(parts: (u128, u128, u128)) -> (u128, u128, Sign) {
            let (positive, negative, denominator) = parts;
            let (magnitude, sign) = match positive.cmp(&negative) {
                Ordering::Greater => (positive - negative, Plus),
                Ordering::Less => (negative - positive, Minus),
                Ordering::Equal => return (0, 1, NoSign),
            };
            let divisor = Rational::gcd_word(magnitude, denominator);
            (magnitude / divisor, denominator / divisor, sign)
        }

        fn compare_magnitudes(left: (u128, u128), right: (u128, u128)) -> Option<Ordering> {
            if left.1 == right.1 {
                return Some(left.0.cmp(&right.0));
            }
            let divisor = Rational::gcd_word(left.1, right.1);
            Some(
                left.0
                    .checked_mul(right.1 / divisor)?
                    .cmp(&right.0.checked_mul(left.1 / divisor)?),
            )
        }

        let (a, b, c) = (words(a)?, words(b)?, words(c)?);
        let ab = [
            difference(b[0], a[0])?,
            difference(b[1], a[1])?,
            difference(b[2], a[2])?,
        ];
        let ac = [
            difference(c[0], a[0])?,
            difference(c[1], a[1])?,
            difference(c[2], a[2])?,
        ];
        let components = [
            reduced_magnitude(component(ab, ac, 1, 2)?),
            reduced_magnitude(component(ab, ac, 2, 0)?),
            reduced_magnitude(component(ab, ac, 0, 1)?),
        ];
        let mut axis = 0;
        for candidate in 1..3 {
            if compare_magnitudes(
                (components[candidate].0, components[candidate].1),
                (components[axis].0, components[axis].1),
            )? == Ordering::Greater
            {
                axis = candidate;
            }
        }
        (components[axis].2 != NoSign).then_some((axis, components[axis].2))
    }

    fn two_product_word_sum(
        first: (Sign, u128, u128),
        second: (Sign, u128, u128),
    ) -> Option<Self> {
        let common_denominator = match (first.0, second.0) {
            (NoSign, NoSign) => return Some(Self::zero()),
            (NoSign, _) => second.2,
            (_, NoSign) => first.2,
            _ if first.2 == second.2 => first.2,
            _ => {
                let divisor = Self::gcd_word(first.2, second.2);
                first.2.checked_mul(second.2 / divisor)?
            }
        };
        let mut positive = 0_u128;
        let mut negative = 0_u128;
        for (sign, magnitude, denominator) in [first, second] {
            if sign == NoSign {
                continue;
            }
            let magnitude = magnitude.checked_mul(common_denominator / denominator)?;
            match sign {
                Plus => positive = positive.checked_add(magnitude)?,
                Minus => negative = negative.checked_add(magnitude)?,
                NoSign => {}
            }
        }
        Some(Self::from_word_magnitude_difference(
            positive,
            negative,
            common_denominator,
        ))
    }

    fn word_product(
        left: (Sign, u128, u128),
        right: (Sign, u128, u128),
        positive: bool,
    ) -> Option<(Sign, u128, u128)> {
        let sign = (if positive { Plus } else { Minus }) * left.0 * right.0;
        if sign == NoSign {
            return Some((NoSign, 0, 1));
        }
        Some((
            sign,
            left.1.checked_mul(right.1)?,
            left.2.checked_mul(right.2)?,
        ))
    }

    fn signed_word_sum(first: (Sign, u128), second: (Sign, u128)) -> Option<(Sign, u128)> {
        match (first.0, second.0) {
            (NoSign, _) => Some(second),
            (_, NoSign) => Some(first),
            (left, right) if left == right => Some((left, first.1.checked_add(second.1)?)),
            _ if first.1 > second.1 => Some((first.0, first.1 - second.1)),
            _ if second.1 > first.1 => Some((second.0, second.1 - first.1)),
            _ => Some((NoSign, 0)),
        }
    }

    #[inline]
    fn checked_word_shift_left(value: u128, shift: u32) -> Option<u128> {
        let factor = 1_u128.checked_shl(shift)?;
        value.checked_mul(factor)
    }

    fn scaled_dyadic_word_part(
        part: (Sign, u128, u128),
        common_shift: u32,
    ) -> Option<(Sign, u128, u128)> {
        let shift = common_shift.checked_sub(part.2.trailing_zeros())?;
        Some((
            part.0,
            Self::checked_word_shift_left(part.1, shift)?,
            1,
        ))
    }

    fn from_scaled_dyadic_quotient_component(
        sign: Sign,
        magnitude: u128,
        denominator: u128,
        scale_shift: i32,
    ) -> Option<Self> {
        if sign == NoSign || magnitude == 0 {
            return Some(Self::zero());
        }

        let divisor = Self::gcd_word(magnitude, denominator);
        Self::from_scaled_dyadic_quotient_component_with_divisor(
            sign,
            magnitude,
            denominator,
            scale_shift,
            divisor,
        )
    }

    fn from_scaled_dyadic_quotient_component_with_divisor(
        sign: Sign,
        mut magnitude: u128,
        mut denominator: u128,
        scale_shift: i32,
        divisor: u128,
    ) -> Option<Self> {
        if sign == NoSign || magnitude == 0 {
            return Some(Self::zero());
        }
        debug_assert_ne!(divisor, 0);
        debug_assert_eq!(magnitude % divisor, 0);
        debug_assert_eq!(denominator % divisor, 0);
        magnitude /= divisor;
        denominator /= divisor;
        if scale_shift >= 0 {
            let shift = scale_shift as u32;
            let cancel = shift.min(denominator.trailing_zeros());
            denominator >>= cancel;
            magnitude = Self::checked_word_shift_left(magnitude, shift - cancel)?;
        } else {
            let shift = scale_shift.unsigned_abs();
            let cancel = shift.min(magnitude.trailing_zeros());
            magnitude >>= cancel;
            denominator = Self::checked_word_shift_left(denominator, shift - cancel)?;
        }
        Some(Self::from_reduced_word_parts(
            sign,
            magnitude,
            denominator,
        ))
    }

    fn from_scaled_dyadic_quotient_component_unreduced(
        sign: Sign,
        mut magnitude: u128,
        mut denominator: u128,
        scale_shift: i32,
    ) -> Option<Self> {
        if sign == NoSign || magnitude == 0 {
            return Some(Self::zero());
        }
        if scale_shift >= 0 {
            let shift = scale_shift as u32;
            let cancel = shift.min(denominator.trailing_zeros());
            denominator >>= cancel;
            magnitude = Self::checked_word_shift_left(magnitude, shift - cancel)?;
        } else {
            let shift = scale_shift.unsigned_abs();
            let cancel = shift.min(magnitude.trailing_zeros());
            magnitude >>= cancel;
            denominator = Self::checked_word_shift_left(denominator, shift - cancel)?;
        }
        Some(Self::from_parts_raw_unreduced(
            sign,
            BigUint::from(magnitude),
            BigUint::from(denominator),
        ))
    }

    fn quotient_dyadic_words(
        numerator: DyadicWord,
        denominator: DyadicWord,
    ) -> Option<(Self, u128)> {
        if denominator.sign == NoSign || denominator.magnitude == 0 {
            return None;
        }
        let divisor = Self::gcd_word(numerator.magnitude, denominator.magnitude);
        let scale_shift = i32::try_from(
            i128::from(denominator.denominator_shift)
                - i128::from(numerator.denominator_shift),
        )
        .ok()?;
        let result = Self::from_scaled_dyadic_quotient_component_with_divisor(
            numerator.sign * denominator.sign,
            numerator.magnitude,
            denominator.magnitude,
            scale_shift,
            divisor,
        )?;
        #[cfg(feature = "dispatch-trace")]
        let numerator_trace = BigUint::from(numerator.magnitude);
        #[cfg(feature = "dispatch-trace")]
        let denominator_trace = BigUint::from(denominator.magnitude);
        #[cfg(feature = "dispatch-trace")]
        let divisor_trace = BigUint::from(divisor);
        trace_rational_gcd!(&numerator_trace, &denominator_trace, &divisor_trace);
        Some((result, divisor))
    }

    fn complex_dyadic_quotient_words(
        parts: [(Sign, u128, u128); 4],
    ) -> Option<Result<(Self, Self), crate::Problem>> {
        if !parts.iter().all(|part| part.2.is_power_of_two()) {
            return None;
        }
        let left_shift = parts[0]
            .2
            .trailing_zeros()
            .max(parts[1].2.trailing_zeros());
        let right_shift = parts[2]
            .2
            .trailing_zeros()
            .max(parts[3].2.trailing_zeros());
        let a = Self::scaled_dyadic_word_part(parts[0], left_shift)?;
        let b = Self::scaled_dyadic_word_part(parts[1], left_shift)?;
        let c = Self::scaled_dyadic_word_part(parts[2], right_shift)?;
        let d = Self::scaled_dyadic_word_part(parts[3], right_shift)?;

        let ac = Self::word_product(a, c, true)?;
        let bd = Self::word_product(b, d, true)?;
        let bc = Self::word_product(b, c, true)?;
        let ad = Self::word_product(a, d, false)?;
        let cc = Self::word_product(c, c, true)?;
        let dd = Self::word_product(d, d, true)?;
        let re = Self::signed_word_sum((ac.0, ac.1), (bd.0, bd.1))?;
        let im = Self::signed_word_sum((bc.0, bc.1), (ad.0, ad.1))?;
        let norm = Self::signed_word_sum((cc.0, cc.1), (dd.0, dd.1))?;
        if norm.0 == NoSign {
            return Some(Err(crate::Problem::DivideByZero));
        }
        let scale_shift = i32::try_from(right_shift).ok()? - i32::try_from(left_shift).ok()?;
        let re = Self::from_scaled_dyadic_quotient_component(
            re.0,
            re.1,
            norm.1,
            scale_shift,
        )?;
        let im = Self::from_scaled_dyadic_quotient_component(
            im.0,
            im.1,
            norm.1,
            scale_shift,
        )?;
        crate::trace_dispatch!("rational", "complex-quotient", "paired-dyadic-word-sized");
        Some(Ok((re, im)))
    }

    fn from_scaled_word_quotient_component(
        sign: Sign,
        mut magnitude: u128,
        mut norm: u128,
        mut scale_numerator: u128,
        mut scale_denominator: u128,
    ) -> Option<Self> {
        if sign == NoSign || magnitude == 0 {
            return Some(Self::zero());
        }

        let divisor = Self::gcd_word(magnitude, norm);
        magnitude /= divisor;
        norm /= divisor;
        if scale_numerator == scale_denominator {
            scale_numerator = 1;
            scale_denominator = 1;
        } else {
            let divisor = Self::gcd_word(scale_numerator, scale_denominator);
            scale_numerator /= divisor;
            scale_denominator /= divisor;
        }
        if scale_denominator != 1 {
            let divisor = Self::gcd_word(magnitude, scale_denominator);
            magnitude /= divisor;
            scale_denominator /= divisor;
        }
        if scale_numerator != 1 {
            let divisor = Self::gcd_word(scale_numerator, norm);
            scale_numerator /= divisor;
            norm /= divisor;
        }

        Some(Self::from_reduced_word_parts(
            sign,
            magnitude.checked_mul(scale_numerator)?,
            norm.checked_mul(scale_denominator)?,
        ))
    }

    fn complex_word_quotient_words(
        parts: [(Sign, u128, u128); 4],
    ) -> Option<Result<(Self, Self), crate::Problem>> {
        let left_denominator = if parts[0].2 == parts[1].2 {
            parts[0].2
        } else {
            let divisor = Self::gcd_word(parts[0].2, parts[1].2);
            parts[0].2.checked_mul(parts[1].2 / divisor)?
        };
        let right_denominator = if parts[2].2 == parts[3].2 {
            parts[2].2
        } else {
            let divisor = Self::gcd_word(parts[2].2, parts[3].2);
            parts[2].2.checked_mul(parts[3].2 / divisor)?
        };
        let a = (
            parts[0].0,
            parts[0].1.checked_mul(left_denominator / parts[0].2)?,
            1,
        );
        let b = (
            parts[1].0,
            parts[1].1.checked_mul(left_denominator / parts[1].2)?,
            1,
        );
        let c = (
            parts[2].0,
            parts[2].1.checked_mul(right_denominator / parts[2].2)?,
            1,
        );
        let d = (
            parts[3].0,
            parts[3].1.checked_mul(right_denominator / parts[3].2)?,
            1,
        );

        let ac = Self::word_product(a, c, true)?;
        let bd = Self::word_product(b, d, true)?;
        let bc = Self::word_product(b, c, true)?;
        let ad = Self::word_product(a, d, false)?;
        let cc = Self::word_product(c, c, true)?;
        let dd = Self::word_product(d, d, true)?;
        let re = Self::signed_word_sum((ac.0, ac.1), (bd.0, bd.1))?;
        let im = Self::signed_word_sum((bc.0, bc.1), (ad.0, ad.1))?;
        let norm = Self::signed_word_sum((cc.0, cc.1), (dd.0, dd.1))?;
        if norm.0 == NoSign {
            return Some(Err(crate::Problem::DivideByZero));
        }
        let re = Self::from_scaled_word_quotient_component(
            re.0,
            re.1,
            norm.1,
            right_denominator,
            left_denominator,
        )?;
        let im = Self::from_scaled_word_quotient_component(
            im.0,
            im.1,
            norm.1,
            right_denominator,
            left_denominator,
        )?;
        crate::trace_dispatch!("rational", "complex-quotient", "paired-general-word-sized");
        Some(Ok((re, im)))
    }

    fn complex_product_components_impl(
        left: [&Self; 2],
        right: [&Self; 2],
        conjugate_right: bool,
    ) -> (Self, Self) {
        let word_parts = [left[0], left[1], right[0], right[1]].map(|value| {
            Some((
                value.sign,
                value.numerator.to_u128()?,
                value.denominator.to_u128()?,
            ))
        });
        if let [Some(a), Some(b), Some(c), Some(d)] = word_parts
            && let (Some(ac), Some(bd), Some(ad), Some(bc)) = (
                Self::word_product(a, c, true),
                Self::word_product(b, d, conjugate_right),
                Self::word_product(a, d, !conjugate_right),
                Self::word_product(b, c, true),
            )
            && let (Some(re), Some(im)) = (
                Self::two_product_word_sum(ac, bd),
                Self::two_product_word_sum(ad, bc),
            )
        {
            crate::trace_dispatch!(
                "rational",
                "complex-product",
                if conjugate_right {
                    "paired-conjugate-word-sized"
                } else {
                    "paired-word-sized"
                }
            );
            return (re, im);
        }

        crate::trace_dispatch!(
            "rational",
            "complex-product",
            if conjugate_right {
                "paired-conjugate-general-fallback"
            } else {
                "paired-general-fallback"
            }
        );
        if conjugate_right {
            (
                Self::signed_product_sum2(
                    [true, true],
                    [[left[0], right[0]], [left[1], right[1]]],
                ),
                Self::signed_product_sum2(
                    [false, true],
                    [[left[0], right[1]], [left[1], right[0]]],
                ),
            )
        } else {
            (
                Self::signed_product_sum2(
                    [true, false],
                    [[left[0], right[0]], [left[1], right[1]]],
                ),
                Self::signed_product_sum2(
                    [true, true],
                    [[left[0], right[1]], [left[1], right[0]]],
                ),
            )
        }
    }

    /// Multiply two exact complex component pairs with one shared word scan.
    ///
    /// Returns `(ac - bd, ad + bc)` for left `(a, b)` and right `(c, d)`.
    /// Word-sized operands convert once; wider products fall back to the
    /// general exact signed-product reducers.
    pub fn complex_product_components(left: [&Self; 2], right: [&Self; 2]) -> (Self, Self) {
        Self::complex_product_components_impl(left, right, false)
    }

    /// Divide two exact complex component pairs with delayed canonicalization.
    ///
    /// The conjugate product `(ac + bd, bc - ad)` is formed with one shared
    /// word scan, while `c² + d²` is reduced once and reused by both output
    /// components. No approximation participates in the zero check or result.
    pub fn complex_quotient_components(
        left: [&Self; 2],
        right: [&Self; 2],
    ) -> Result<(Self, Self), crate::Problem> {
        let word_parts = [left[0], left[1], right[0], right[1]].map(|value| {
            Some((
                value.sign,
                value.numerator.to_u128()?,
                value.denominator.to_u128()?,
            ))
        });
        if let [Some(a), Some(b), Some(c), Some(d)] = word_parts
        {
            if let Some(result) = Self::complex_dyadic_quotient_words([a, b, c, d]) {
                return result;
            }
            if let Some(result) = Self::complex_word_quotient_words([a, b, c, d]) {
                return result;
            }
        }

        let (re_numerator, im_numerator) =
            Self::complex_product_components_impl(left, right, true);
        let denominator =
            Self::signed_product_sum2([true, true], [[right[0], right[0]], [right[1], right[1]]]);
        if denominator.sign == NoSign {
            return Err(crate::Problem::DivideByZero);
        }
        crate::trace_dispatch!("rational", "complex-quotient", "paired-exact-rational");
        Ok((
            &re_numerator / &denominator,
            &im_numerator / &denominator,
        ))
    }

    /// Construct a homogeneous three-plane intersection when one exact row
    /// has a single nonzero coefficient.
    ///
    /// The sparse coefficient is a common projective scale. Applying it once
    /// to each two-by-two minor reproduces the exact signed cofactor tuple
    /// without expanding four independent three-by-three determinants.
    pub(crate) fn homogeneous_plane_intersection3_sparse(
        matrix: [[&Self; 4]; 3],
        sparse_row: usize,
        sparse_column: usize,
    ) -> [Self; 4] {
        let other_rows: [usize; 2] = match sparse_row {
            0 => [1, 2],
            1 => [0, 2],
            _ => [0, 1],
        };
        let mut columns = [0_usize; 3];
        let mut next = 0;
        for column in 0..4 {
            if column != sparse_column {
                columns[next] = column;
                next += 1;
            }
        }
        let [first, second, third] = columns;
        let left = matrix[other_rows[0]].map(Self::canonicalized_ref);
        let right = matrix[other_rows[1]].map(Self::canonicalized_ref);
        let scale = matrix[sparse_row][sparse_column].canonicalized_ref();
        let positive_terms = if (sparse_row + sparse_column) & 1 == 0 {
            [true, false]
        } else {
            [false, true]
        };
        let dyadic = columns.into_iter().all(|column| {
            left[column].dyadic_denominator_shift().is_some()
                && right[column].dyadic_denominator_shift().is_some()
        });
        let difference = |terms| {
            if dyadic {
                Self::signed_product_sum_known_dyadic(positive_terms, terms)
            } else {
                let positive = terms[0][0] * terms[0][1];
                let negative = terms[1][0] * terms[1][1];
                if positive_terms[0] {
                    &positive - &negative
                } else {
                    &negative - &positive
                }
            }
        };
        let cross = [
            difference([[left[second], right[third]], [left[third], right[second]]]),
            difference([[left[third], right[first]], [left[first], right[third]]]),
            difference([[left[first], right[second]], [left[second], right[first]]]),
        ];
        let mut result = core::array::from_fn(|_| Self::zero());
        for (column, value) in columns.into_iter().zip(cross) {
            result[column] = &value * scale;
        }
        crate::trace_dispatch!(
            "rational",
            "homogeneous-plane-intersection3",
            "sparse-exact-row-scaled-cofactors"
        );
        result
    }

    /// Invert a fixed 3x3 exact-rational matrix as one aggregate operation.
    ///
    /// Keeping the cofactors and shared determinant reciprocal in `Rational`
    /// avoids repeatedly reclassifying and wrapping intermediate `Real`
    /// values. Each signed product is still fused and every returned component
    /// remains canonically exact.
    pub(crate) fn matrix3_inverse_components(
        matrix: [[&Self; 3]; 3],
    ) -> Result<[[Self; 3]; 3], crate::Problem> {
        Self::matrix3_inverse_components_impl::<false>(matrix)
    }

    /// Invert a fixed 3x3 matrix after the caller classified every component dyadic.
    pub(crate) fn matrix3_inverse_components_known_dyadic(
        matrix: [[&Self; 3]; 3],
    ) -> Result<[[Self; 3]; 3], crate::Problem> {
        Self::matrix3_inverse_components_impl::<true>(matrix)
    }

    fn matrix3_inverse_components_impl<const KNOWN_DYADIC: bool>(
        matrix: [[&Self; 3]; 3],
    ) -> Result<[[Self; 3]; 3], crate::Problem> {
        let m = matrix;
        let difference = |terms| {
            if KNOWN_DYADIC {
                Self::signed_product_sum_known_dyadic([true, false], terms)
            } else {
                Self::signed_product_sum2([true, false], terms)
            }
        };
        let c00 = difference([[m[1][1], m[2][2]], [m[1][2], m[2][1]]]);
        let c01 = difference([[m[0][2], m[2][1]], [m[0][1], m[2][2]]]);
        let c02 = difference([[m[0][1], m[1][2]], [m[0][2], m[1][1]]]);
        let c10 = difference([[m[1][2], m[2][0]], [m[1][0], m[2][2]]]);
        let c11 = difference([[m[0][0], m[2][2]], [m[0][2], m[2][0]]]);
        let c12 = difference([[m[0][2], m[1][0]], [m[0][0], m[1][2]]]);
        let c20 = difference([[m[1][0], m[2][1]], [m[1][1], m[2][0]]]);
        let c21 = difference([[m[0][1], m[2][0]], [m[0][0], m[2][1]]]);
        let c22 = difference([[m[0][0], m[1][1]], [m[0][1], m[1][0]]]);
        let determinant_terms = [
            [m[0][0], &c00],
            [m[0][1], &c10],
            [m[0][2], &c20],
        ];
        let determinant = if KNOWN_DYADIC {
            Self::signed_product_sum_known_dyadic([true, true, true], determinant_terms)
        } else {
            Self::signed_product_sum([true, true, true], determinant_terms)
        };
        let inverse_determinant = determinant.inverse()?;
        crate::trace_dispatch!("rational", "matrix3-inverse", "aggregate-cofactor");
        Ok([
            [
                c00 * &inverse_determinant,
                c01 * &inverse_determinant,
                c02 * &inverse_determinant,
            ],
            [
                c10 * &inverse_determinant,
                c11 * &inverse_determinant,
                c12 * &inverse_determinant,
            ],
            [
                c20 * &inverse_determinant,
                c21 * &inverse_determinant,
                c22 * &inverse_determinant,
            ],
        ])
    }

    /// Invert a fixed 4x4 exact-rational matrix as one aggregate operation.
    ///
    /// Keeping fixed minors and cofactors in `Rational` avoids wrapping and
    /// reclassifying every intermediate as a `Real`, while preserving the
    /// same division-free cofactor polynomial and exact reductions.
    pub(crate) fn matrix4_inverse_components(
        matrix: [[&Self; 4]; 4],
    ) -> Result<[[Self; 4]; 4], crate::Problem> {
        Self::matrix4_inverse_components_impl(matrix)
    }

    /// Invert a fixed 4x4 matrix after the caller classified every component dyadic.
    pub(crate) fn matrix4_inverse_components_known_dyadic(
        matrix: [[&Self; 4]; 4],
    ) -> Result<[[Self; 4]; 4], crate::Problem> {
        // Lift each row onto its smallest integer grid. If B = D A for the
        // diagonal power-of-two scale D, then A^-1 = B^-1 D. This keeps every
        // minor fraction-free and avoids allocating cache-bearing Rational
        // nodes until the sixteen final adjugate/determinant quotients.
        let row_shifts: [u64; 4] = matrix.map(|row| {
            row.into_iter()
                .map(|value| {
                    let value = value.canonicalized_ref();
                    value
                        .dyadic_denominator_shift()
                        .expect("known-dyadic matrix received a non-dyadic component")
                })
                .max()
                .expect("matrix rows are nonempty")
        });
        let m: [[BigInt; 4]; 4] = core::array::from_fn(|row| {
            core::array::from_fn(|column| {
                let value = matrix[row][column].canonicalized_ref();
                let denominator_shift = value
                    .dyadic_denominator_shift()
                    .expect("known-dyadic matrix received a non-dyadic component");
                let lift = usize::try_from(row_shifts[row] - denominator_shift)
                    .expect("dyadic matrix row shift fits usize");
                BigInt::from_biguint(value.sign, value.numerator.clone()) << lift
            })
        });
        let difference = |a: &BigInt, b: &BigInt, c: &BigInt, d: &BigInt| a * b - c * d;
        let s = [
            difference(&m[0][0], &m[1][1], &m[1][0], &m[0][1]),
            difference(&m[0][0], &m[1][2], &m[1][0], &m[0][2]),
            difference(&m[0][0], &m[1][3], &m[1][0], &m[0][3]),
            difference(&m[0][1], &m[1][2], &m[1][1], &m[0][2]),
            difference(&m[0][1], &m[1][3], &m[1][1], &m[0][3]),
            difference(&m[0][2], &m[1][3], &m[1][2], &m[0][3]),
        ];
        let c = [
            difference(&m[2][0], &m[3][1], &m[3][0], &m[2][1]),
            difference(&m[2][0], &m[3][2], &m[3][0], &m[2][2]),
            difference(&m[2][0], &m[3][3], &m[3][0], &m[2][3]),
            difference(&m[2][1], &m[3][2], &m[3][1], &m[2][2]),
            difference(&m[2][1], &m[3][3], &m[3][1], &m[2][3]),
            difference(&m[2][2], &m[3][3], &m[3][2], &m[2][3]),
        ];
        let determinant = &s[0] * &c[5] - &s[1] * &c[4]
            + &s[2] * &c[3]
            + &s[3] * &c[2]
            - &s[4] * &c[1]
            + &s[5] * &c[0];
        let (determinant_sign, determinant) = determinant.into_parts();
        if determinant_sign == NoSign {
            return Err(crate::Problem::DivideByZero);
        }
        let cofactor = |positive_terms: [bool; 3], terms: [[&BigInt; 2]; 3], column: usize| {
            let mut value = BigInt::ZERO;
            for index in 0..3 {
                let term = terms[index][0] * terms[index][1];
                if positive_terms[index] {
                    value += term;
                } else {
                    value -= term;
                }
            }
            if determinant_sign == Minus {
                value = -value;
            }
            value <<= usize::try_from(row_shifts[column]).expect("dyadic row shift fits usize");
            Self::from_bigint_fraction(value, determinant.clone())
                .expect("matrix determinant is nonzero")
        };
        crate::trace_dispatch!("rational", "matrix4-inverse", "row-scaled-dyadic-integer");
        Ok([
            [
                cofactor([true, true, false], [[&m[1][1], &c[5]], [&m[1][3], &c[3]], [&m[1][2], &c[4]]], 0),
                cofactor([true, false, false], [[&m[0][2], &c[4]], [&m[0][1], &c[5]], [&m[0][3], &c[3]]], 1),
                cofactor([true, true, false], [[&m[3][1], &s[5]], [&m[3][3], &s[3]], [&m[3][2], &s[4]]], 2),
                cofactor([true, false, false], [[&m[2][2], &s[4]], [&m[2][1], &s[5]], [&m[2][3], &s[3]]], 3),
            ],
            [
                cofactor([true, false, false], [[&m[1][2], &c[2]], [&m[1][0], &c[5]], [&m[1][3], &c[1]]], 0),
                cofactor([true, true, false], [[&m[0][0], &c[5]], [&m[0][3], &c[1]], [&m[0][2], &c[2]]], 1),
                cofactor([true, false, false], [[&m[3][2], &s[2]], [&m[3][0], &s[5]], [&m[3][3], &s[1]]], 2),
                cofactor([true, true, false], [[&m[2][0], &s[5]], [&m[2][3], &s[1]], [&m[2][2], &s[2]]], 3),
            ],
            [
                cofactor([true, true, false], [[&m[1][0], &c[4]], [&m[1][3], &c[0]], [&m[1][1], &c[2]]], 0),
                cofactor([true, false, false], [[&m[0][1], &c[2]], [&m[0][0], &c[4]], [&m[0][3], &c[0]]], 1),
                cofactor([true, true, false], [[&m[3][0], &s[4]], [&m[3][3], &s[0]], [&m[3][1], &s[2]]], 2),
                cofactor([true, false, false], [[&m[2][1], &s[2]], [&m[2][0], &s[4]], [&m[2][3], &s[0]]], 3),
            ],
            [
                cofactor([true, false, false], [[&m[1][1], &c[1]], [&m[1][0], &c[3]], [&m[1][2], &c[0]]], 0),
                cofactor([true, true, false], [[&m[0][0], &c[3]], [&m[0][2], &c[0]], [&m[0][1], &c[1]]], 1),
                cofactor([true, false, false], [[&m[3][1], &s[1]], [&m[3][0], &s[3]], [&m[3][2], &s[0]]], 2),
                cofactor([true, true, false], [[&m[2][0], &s[3]], [&m[2][2], &s[0]], [&m[2][1], &s[1]]], 3),
            ],
        ])
    }

    fn matrix4_inverse_components_impl(
        matrix: [[&Self; 4]; 4],
    ) -> Result<[[Self; 4]; 4], crate::Problem> {
        let m = matrix;
        let difference = |a: &Self, b: &Self, c: &Self, d: &Self| {
            Self::signed_product_sum2([true, false], [[a, b], [c, d]])
        };
        let s = [
            difference(m[0][0], m[1][1], m[1][0], m[0][1]),
            difference(m[0][0], m[1][2], m[1][0], m[0][2]),
            difference(m[0][0], m[1][3], m[1][0], m[0][3]),
            difference(m[0][1], m[1][2], m[1][1], m[0][2]),
            difference(m[0][1], m[1][3], m[1][1], m[0][3]),
            difference(m[0][2], m[1][3], m[1][2], m[0][3]),
        ];
        let c = [
            difference(m[2][0], m[3][1], m[3][0], m[2][1]),
            difference(m[2][0], m[3][2], m[3][0], m[2][2]),
            difference(m[2][0], m[3][3], m[3][0], m[2][3]),
            difference(m[2][1], m[3][2], m[3][1], m[2][2]),
            difference(m[2][1], m[3][3], m[3][1], m[2][3]),
            difference(m[2][2], m[3][3], m[3][2], m[2][3]),
        ];
        let determinant_terms = [
            [&s[0], &c[5]],
            [&s[1], &c[4]],
            [&s[2], &c[3]],
            [&s[3], &c[2]],
            [&s[4], &c[1]],
            [&s[5], &c[0]],
        ];
        let determinant_signs = [true, false, true, true, false, true];
        let determinant = Self::signed_product_sum(determinant_signs, determinant_terms);
        let scale = determinant.inverse()?;
        let cofactor = |positive_terms: [bool; 3], terms: [[&Self; 2]; 3]| {
            let value = Self::signed_product_sum(positive_terms, terms);
            value * &scale
        };
        crate::trace_dispatch!("rational", "matrix4-inverse", "aggregate-cofactor");
        Ok([
            [
                cofactor([true, true, false], [[m[1][1], &c[5]], [m[1][3], &c[3]], [m[1][2], &c[4]]]),
                cofactor([true, false, false], [[m[0][2], &c[4]], [m[0][1], &c[5]], [m[0][3], &c[3]]]),
                cofactor([true, true, false], [[m[3][1], &s[5]], [m[3][3], &s[3]], [m[3][2], &s[4]]]),
                cofactor([true, false, false], [[m[2][2], &s[4]], [m[2][1], &s[5]], [m[2][3], &s[3]]]),
            ],
            [
                cofactor([true, false, false], [[m[1][2], &c[2]], [m[1][0], &c[5]], [m[1][3], &c[1]]]),
                cofactor([true, true, false], [[m[0][0], &c[5]], [m[0][3], &c[1]], [m[0][2], &c[2]]]),
                cofactor([true, false, false], [[m[3][2], &s[2]], [m[3][0], &s[5]], [m[3][3], &s[1]]]),
                cofactor([true, true, false], [[m[2][0], &s[5]], [m[2][3], &s[1]], [m[2][2], &s[2]]]),
            ],
            [
                cofactor([true, true, false], [[m[1][0], &c[4]], [m[1][3], &c[0]], [m[1][1], &c[2]]]),
                cofactor([true, false, false], [[m[0][1], &c[2]], [m[0][0], &c[4]], [m[0][3], &c[0]]]),
                cofactor([true, true, false], [[m[3][0], &s[4]], [m[3][3], &s[0]], [m[3][1], &s[2]]]),
                cofactor([true, false, false], [[m[2][1], &s[2]], [m[2][0], &s[4]], [m[2][3], &s[0]]]),
            ],
            [
                cofactor([true, false, false], [[m[1][1], &c[1]], [m[1][0], &c[3]], [m[1][2], &c[0]]]),
                cofactor([true, true, false], [[m[0][0], &c[3]], [m[0][2], &c[0]], [m[0][1], &c[1]]]),
                cofactor([true, false, false], [[m[3][1], &s[1]], [m[3][0], &s[3]], [m[3][2], &s[0]]]),
                cofactor([true, true, false], [[m[2][0], &s[3]], [m[2][2], &s[0]], [m[2][1], &s[1]]]),
            ],
        ])
    }

    fn known_dyadic_word(value: &Self) -> Option<DyadicWord> {
        let value = value.canonicalized_ref();
        Some(DyadicWord {
            sign: value.sign,
            magnitude: value.numerator.to_u128()?,
            denominator_shift: value.dyadic_denominator_shift()?,
        })
    }

    /// Construct the oriented affine plane through three dyadic points.
    ///
    /// Coordinate differences, cross products, and the offset remain in
    /// checked native-word or fixed-stack form. A value outside that envelope
    /// returns `None` so the caller can retain its arbitrary-precision
    /// determinant construction.
    #[doc(hidden)]
    pub fn affine_plane3_coefficients_known_dyadic(
        points: [[&Self; 3]; 3],
    ) -> Option<[Self; 4]> {
        let point_words = |point: [&Self; 3]| {
            Some([
                Self::known_dyadic_word(point[0])?,
                Self::known_dyadic_word(point[1])?,
                Self::known_dyadic_word(point[2])?,
            ])
        };
        let first = point_words(points[0])?;
        let second = point_words(points[1])?;
        let third = point_words(points[2])?;
        let difference = |left: [DyadicWord; 3], right: [DyadicWord; 3]| {
            Some([
                Self::difference_dyadic_words(left[0], right[0])?,
                Self::difference_dyadic_words(left[1], right[1])?,
                Self::difference_dyadic_words(left[2], right[2])?,
            ])
        };
        let u = difference(second, first)?;
        let v = difference(third, first)?;
        let normal = [
            Self::cross_dyadic_words([u[1], u[2]], [v[1], v[2]])?,
            Self::cross_dyadic_words([u[2], u[0]], [v[2], v[0]])?,
            Self::cross_dyadic_words([u[0], u[1]], [v[0], v[1]])?,
        ];
        let normal_wide = [
            Self::dyadic_stack_sum_wide_word(normal[0])?,
            Self::dyadic_stack_sum_wide_word(normal[1])?,
            Self::dyadic_stack_sum_wide_word(normal[2])?,
        ];
        let offset =
            Self::product_sum_wide_narrow_words(normal_wide, first, [false; 3])?;
        crate::trace_dispatch!("rational", "affine-plane3", "dyadic-stack-fused");
        Some([
            Self::materialize_dyadic_stack_sum(normal[0]),
            Self::materialize_dyadic_stack_sum(normal[1]),
            Self::materialize_dyadic_stack_sum(normal[2]),
            Self::materialize_dyadic_stack_sum(offset),
        ])
    }

    fn difference_dyadic_words(left: DyadicWord, right: DyadicWord) -> Option<DyadicWord> {
        let denominator_shift = left.denominator_shift.max(right.denominator_shift);
        let align = |value: DyadicWord| {
            let shift = u32::try_from(denominator_shift - value.denominator_shift).ok()?;
            Some((
                value.sign,
                Self::checked_word_shift_left(value.magnitude, shift)?,
            ))
        };
        let (sign, mut magnitude) = Self::signed_word_sum(align(left)?, {
            let (sign, magnitude) = align(right)?;
            (-sign, magnitude)
        })?;
        if sign == NoSign {
            return Some(DyadicWord {
                sign,
                magnitude: 0,
                denominator_shift: 0,
            });
        }
        let common_shift = u64::from(magnitude.trailing_zeros()).min(denominator_shift);
        magnitude >>= common_shift;
        Some(DyadicWord {
            sign,
            magnitude,
            denominator_shift: denominator_shift - common_shift,
        })
    }

    fn finish_dyadic_stack_sum(
        positive: DyadicStackAccumulator,
        negative: DyadicStackAccumulator,
        max_shift: u64,
    ) -> DyadicStackSum {
        let Some((sign, mut magnitude)) =
            DyadicStackAccumulator::difference(positive, negative)
        else {
            return DyadicStackSum {
                sign: NoSign,
                magnitude: DyadicStackAccumulator::default(),
                denominator_shift: 0,
            };
        };
        let common_shift = magnitude.trailing_zeros().min(max_shift);
        magnitude.shift_right(common_shift);
        DyadicStackSum {
            sign,
            magnitude,
            denominator_shift: max_shift - common_shift,
        }
    }

    fn dyadic_stack_sum_word(sum: DyadicStackSum) -> Option<DyadicWord> {
        Some(DyadicWord {
            sign: sum.sign,
            magnitude: sum.magnitude.to_u128()?,
            denominator_shift: sum.denominator_shift,
        })
    }

    fn dyadic_word_stack_sum(word: DyadicWord) -> DyadicStackSum {
        let mut magnitude = DyadicStackAccumulator::default();
        magnitude.0[0] = word.magnitude as u64;
        magnitude.0[1] = (word.magnitude >> 64) as u64;
        DyadicStackSum {
            sign: word.sign,
            magnitude,
            denominator_shift: word.denominator_shift,
        }
    }

    fn dyadic_stack_sum_wide_word(sum: DyadicStackSum) -> Option<DyadicWideWord> {
        if sum.magnitude.0[4..].iter().any(|limb| *limb != 0) {
            return None;
        }
        Some(DyadicWideWord {
            sign: sum.sign,
            magnitude: sum.magnitude.0[..4]
                .try_into()
                .expect("four-limb prefix has fixed width"),
            denominator_shift: sum.denominator_shift,
        })
    }

    fn product_sum_dyadic_words<const N: usize>(
        left: [DyadicWord; N],
        right: [DyadicWord; N],
        positive_terms: [bool; N],
    ) -> Option<DyadicStackSum> {
        let denominator_shifts: [u64; N] = core::array::from_fn(|index| {
            left[index].denominator_shift + right[index].denominator_shift
        });
        let max_shift = denominator_shifts.into_iter().max().unwrap_or(0);
        let mut positive = DyadicStackAccumulator::default();
        let mut negative = DyadicStackAccumulator::default();
        for index in 0..N {
            let sign = (if positive_terms[index] { Plus } else { Minus })
                * left[index].sign
                * right[index].sign;
            let accumulator = match sign {
                Plus => &mut positive,
                Minus => &mut negative,
                NoSign => continue,
            };
            accumulator.add_product(
                left[index].magnitude,
                right[index].magnitude,
                max_shift - denominator_shifts[index],
            )?;
        }
        Some(Self::finish_dyadic_stack_sum(
            positive, negative, max_shift,
        ))
    }

    #[inline]
    fn product_sum2_dyadic_words_word(
        left: [DyadicWord; 2],
        right: [DyadicWord; 2],
        positive_terms: [bool; 2],
    ) -> Option<DyadicWord> {
        let denominator_shifts = [
            left[0].denominator_shift + right[0].denominator_shift,
            left[1].denominator_shift + right[1].denominator_shift,
        ];
        let max_shift = denominator_shifts[0].max(denominator_shifts[1]);
        let product = |index: usize| {
            let sign = (if positive_terms[index] { Plus } else { Minus })
                * left[index].sign
                * right[index].sign;
            if sign == NoSign {
                return Some((NoSign, 0));
            }
            let shift = u32::try_from(max_shift - denominator_shifts[index]).ok()?;
            let magnitude = left[index]
                .magnitude
                .checked_mul(right[index].magnitude)
                .and_then(|magnitude| Self::checked_word_shift_left(magnitude, shift))?;
            Some((sign, magnitude))
        };
        let sum = Self::signed_word_sum(product(0)?, product(1)?)?;
        if sum.0 == NoSign {
            return Some(DyadicWord {
                sign: NoSign,
                magnitude: 0,
                denominator_shift: 0,
            });
        }
        let common_shift = u64::from(sum.1.trailing_zeros()).min(max_shift);
        Some(DyadicWord {
            sign: sum.0,
            magnitude: sum.1 >> common_shift,
            denominator_shift: max_shift - common_shift,
        })
    }

    fn cross_dyadic_words(left: [DyadicWord; 2], right: [DyadicWord; 2]) -> Option<DyadicStackSum> {
        Self::product_sum_dyadic_words(
            [left[0], left[1]],
            [right[1], right[0]],
            [true, false],
        )
    }

    fn cross_dyadic_words_word(
        left: [DyadicWord; 2],
        right: [DyadicWord; 2],
    ) -> Option<DyadicWord> {
        Self::product_sum2_dyadic_words_word(
            [left[0], left[1]],
            [right[1], right[0]],
            [true, false],
        )
    }

    fn product_sum_wide_narrow_words<const N: usize>(
        left: [DyadicWideWord; N],
        right: [DyadicWord; N],
        positive_terms: [bool; N],
    ) -> Option<DyadicStackSum> {
        let denominator_shifts: [u64; N] = core::array::from_fn(|index| {
            left[index].denominator_shift + right[index].denominator_shift
        });
        let max_shift = denominator_shifts.into_iter().max().unwrap_or(0);
        let mut positive = DyadicStackAccumulator::default();
        let mut negative = DyadicStackAccumulator::default();
        for index in 0..N {
            let sign = (if positive_terms[index] { Plus } else { Minus })
                * left[index].sign
                * right[index].sign;
            let accumulator = match sign {
                Plus => &mut positive,
                Minus => &mut negative,
                NoSign => continue,
            };
            accumulator.add_wide_word_product(
                left[index].magnitude,
                right[index].magnitude,
                max_shift - denominator_shifts[index],
            )?;
        }
        Some(Self::finish_dyadic_stack_sum(
            positive, negative, max_shift,
        ))
    }

    fn dyadic_product_alignment<const N: usize>(
        left: [&Self; N],
        right: [&Self; N],
        signs: [Sign; N],
    ) -> Option<([u64; N], u64)> {
        let mut max_shift = 0_u64;
        let mut denominator_shifts = [0_u64; N];
        for i in 0..N {
            if signs[i] == NoSign {
                continue;
            }
            let shift = left[i].dyadic_denominator_shift_if_reduced()?
                + right[i].dyadic_denominator_shift_if_reduced()?;
            denominator_shifts[i] = shift;
            max_shift = max_shift.max(shift);
        }
        Some((denominator_shifts, max_shift))
    }

    fn dot_products_dyadic<const N: usize>(
        left: [&Self; N],
        right: [&Self; N],
        signs: [Sign; N],
    ) -> Option<Self> {
        let (denominator_shifts, max_shift) =
            Self::dyadic_product_alignment(left, right, signs)?;

        if let Some(result) =
            Self::dot_products_dyadic_words(left, right, signs, denominator_shifts, max_shift)
        {
            crate::trace_dispatch!("rational", "dot_product", "dyadic-word-accumulator");
            return Some(result);
        }

        if let Some(result) =
            Self::dot_products_dyadic_stack(left, right, signs, denominator_shifts, max_shift)
        {
            crate::trace_dispatch!("rational", "dot_product", "dyadic-stack-accumulator");
            return Some(result);
        }

        let mut positive = BigUint::ZERO;
        let mut negative = BigUint::ZERO;
        for i in 0..N {
            let sign = signs[i];
            if sign == NoSign {
                continue;
            }
            let scale_shift = usize::try_from(max_shift - denominator_shifts[i])
                .expect("dyadic dot-product scale should fit in usize");
            let mut magnitude = &left[i].numerator * &right[i].numerator;
            if scale_shift != 0 {
                magnitude <<= scale_shift;
            }
            match sign {
                Plus => positive += magnitude,
                Minus => negative += magnitude,
                NoSign => {}
            }
        }

        let denominator =
            BigUint::one() << usize::try_from(max_shift).expect("shift should fit in usize");
        Some(Self::from_signed_magnitude_difference(
            positive,
            negative,
            denominator,
        ))
    }

    fn dot_products_dyadic_stack<const N: usize>(
        left: [&Self; N],
        right: [&Self; N],
        signs: [Sign; N],
        denominator_shifts: [u64; N],
        max_shift: u64,
    ) -> Option<Self> {
        Self::dot_products_dyadic_stack_sum(
            left,
            right,
            signs,
            denominator_shifts,
            max_shift,
        )
        .map(Self::materialize_dyadic_stack_sum)
    }

    fn dot_products_known_dyadic_stack_sum<const N: usize>(
        left: [&Self; N],
        right: [&Self; N],
        signs: [Sign; N],
    ) -> Option<DyadicStackSum> {
        let (denominator_shifts, max_shift) =
            Self::dyadic_product_alignment(left, right, signs)?;
        Self::dot_products_dyadic_stack_sum(
            left,
            right,
            signs,
            denominator_shifts,
            max_shift,
        )
    }

    fn dot_products_dyadic_stack_sum<const N: usize>(
        left: [&Self; N],
        right: [&Self; N],
        signs: [Sign; N],
        denominator_shifts: [u64; N],
        max_shift: u64,
    ) -> Option<DyadicStackSum> {
        let mut positive = DyadicStackAccumulator::default();
        let mut negative = DyadicStackAccumulator::default();
        for i in 0..N {
            let accumulator = match signs[i] {
                Plus => &mut positive,
                Minus => &mut negative,
                NoSign => continue,
            };
            accumulator.add_product(
                left[i].numerator.to_u128()?,
                right[i].numerator.to_u128()?,
                max_shift - denominator_shifts[i],
            )?;
        }

        Some(Self::finish_dyadic_stack_sum(
            positive, negative, max_shift,
        ))
    }

    fn materialize_dyadic_stack_sum(sum: DyadicStackSum) -> Self {
        if sum.sign == NoSign {
            return Self::zero();
        }
        if sum.denominator_shift < 128
            && let Some(magnitude) = sum.magnitude.to_u128()
        {
            return Self::from_reduced_word_parts(
                sum.sign,
                magnitude,
                1_u128 << sum.denominator_shift,
            );
        }

        let denominator = BigUint::one()
            << usize::try_from(sum.denominator_shift).expect("dyadic shift fits usize");
        trace_rational_temporary!();
        Self::from_parts_raw(
            sum.sign,
            sum.magnitude.into_biguint(),
            denominator,
        )
    }

    fn signed_product_sum_dyadic_word_totals<
        const TERMS: usize,
        const FACTORS: usize,
    >(
        terms: [[&Self; FACTORS]; TERMS],
        signs: [Sign; TERMS],
        denominator_shifts: [u64; TERMS],
        max_shift: u64,
    ) -> Option<(u128, u128)> {
        let mut positive = 0_u128;
        let mut negative = 0_u128;
        for i in 0..TERMS {
            let sign = signs[i];
            if sign == NoSign {
                continue;
            }
            let mut magnitude = 1_u128;
            for factor in terms[i] {
                magnitude = magnitude.checked_mul(factor.numerator.to_u128()?)?;
            }
            let scale_shift = u32::try_from(max_shift - denominator_shifts[i]).ok()?;
            let magnitude = Self::checked_word_shift_left(magnitude, scale_shift)?;
            match sign {
                Plus => positive = positive.checked_add(magnitude)?,
                Minus => negative = negative.checked_add(magnitude)?,
                NoSign => {}
            }
        }
        Some((positive, negative))
    }

    fn signed_product_sum_dyadic_word_totals_unplanned<
        const TERMS: usize,
        const FACTORS: usize,
    >(
        positive_terms: [bool; TERMS],
        terms: [[&Self; FACTORS]; TERMS],
    ) -> Option<(u128, u128)> {
        let mut positive = 0_u128;
        let mut negative = 0_u128;
        let mut max_shift = 0_u64;
        for i in 0..TERMS {
            let sign = Self::product_term_sign(positive_terms[i], terms[i]);
            if sign == NoSign {
                continue;
            }
            let mut magnitude = 1_u128;
            let mut shift = 0_u64;
            for factor in terms[i] {
                shift =
                    shift.checked_add(factor.dyadic_denominator_shift_if_reduced()?)?;
                magnitude = magnitude.checked_mul(factor.numerator.to_u128()?)?;
            }
            // Both totals stay aligned to `max_shift`. Because each side is a
            // monotonic sum of magnitudes, raising that alignment has the same
            // checked-word success envelope as scaling every term afterward.
            if shift > max_shift {
                if positive != 0 || negative != 0 {
                    let scale_shift = u32::try_from(shift - max_shift).ok()?;
                    positive = Self::checked_word_shift_left(positive, scale_shift)?;
                    negative = Self::checked_word_shift_left(negative, scale_shift)?;
                }
                max_shift = shift;
            } else if shift < max_shift {
                let scale_shift = u32::try_from(max_shift - shift).ok()?;
                magnitude = Self::checked_word_shift_left(magnitude, scale_shift)?;
            }
            match sign {
                Plus => positive = positive.checked_add(magnitude)?,
                Minus => negative = negative.checked_add(magnitude)?,
                NoSign => {}
            }
        }
        Some((positive, negative))
    }

    fn signed_product_sum_dyadic_words_with_plan<
        const TERMS: usize,
        const FACTORS: usize,
    >(
        terms: [[&Self; FACTORS]; TERMS],
        signs: [Sign; TERMS],
        denominator_shifts: [u64; TERMS],
        max_shift: u64,
    ) -> Option<Self> {
        let (positive, negative) = Self::signed_product_sum_dyadic_word_totals(
            terms,
            signs,
            denominator_shifts,
            max_shift,
        )?;
        let (sign, mut magnitude) = match positive.cmp(&negative) {
            Ordering::Greater => (Plus, positive - negative),
            Ordering::Less => (Minus, negative - positive),
            Ordering::Equal => return Some(Self::zero()),
        };
        let common_shift = u64::from(magnitude.trailing_zeros()).min(max_shift);
        magnitude >>= u32::try_from(common_shift).expect("u128 trailing-zero count fits u32");
        let denominator_shift = max_shift - common_shift;
        if denominator_shift < 128 {
            return Some(Self::from_reduced_word_parts(
                sign,
                magnitude,
                1_u128 << denominator_shift,
            ));
        }

        let denominator = BigUint::one()
            << usize::try_from(denominator_shift).expect("dyadic shift fits usize");
        trace_rational_temporary!();
        Some(Self::from_parts_raw(
            sign,
            BigUint::from(magnitude),
            denominator,
        ))
    }

    fn dot_products_dyadic_words<const N: usize>(
        left: [&Self; N],
        right: [&Self; N],
        signs: [Sign; N],
        denominator_shifts: [u64; N],
        max_shift: u64,
    ) -> Option<Self> {
        let terms = std::array::from_fn(|i| [left[i], right[i]]);
        Self::signed_product_sum_dyadic_words_with_plan(
            terms,
            signs,
            denominator_shifts,
            max_shift,
        )
    }

    fn dot_products_equal_denominator<const N: usize>(
        left: [&Self; N],
        right: [&Self; N],
        signs: [Sign; N],
    ) -> Option<Self> {
        let mut shared_denominator = None::<BigUint>;
        for i in 0..N {
            if signs[i] == NoSign {
                continue;
            }
            let denominator = &left[i].denominator * &right[i].denominator;
            match &shared_denominator {
                None => shared_denominator = Some(denominator),
                Some(shared) if *shared == denominator => {}
                Some(_) => return None,
            }
        }

        let Some(denominator) = shared_denominator else {
            return Some(Self::zero());
        };

        let mut positive = BigUint::ZERO;
        let mut negative = BigUint::ZERO;
        for i in 0..N {
            let sign = signs[i];
            if sign == NoSign {
                continue;
            }
            let magnitude = &left[i].numerator * &right[i].numerator;
            match sign {
                Plus => positive += magnitude,
                Minus => negative += magnitude,
                NoSign => {}
            }
        }

        Some(Self::from_signed_magnitude_difference(
            positive,
            negative,
            denominator,
        ))
    }

    fn product_term_denominator<const FACTORS: usize>(term: [&Self; FACTORS]) -> BigUint {
        let mut factors = term.into_iter();
        let Some(first) = factors.next() else {
            return BigUint::one();
        };
        let mut denominator = first.denominator.clone();
        for factor in factors {
            denominator *= &factor.denominator;
        }
        denominator
    }

    fn product_term_magnitude<const FACTORS: usize>(term: [&Self; FACTORS]) -> BigUint {
        let mut factors = term.into_iter();
        let Some(first) = factors.next() else {
            return BigUint::one();
        };
        let mut magnitude = first.numerator.clone();
        for factor in factors {
            magnitude *= &factor.numerator;
        }
        magnitude
    }

    fn product_term_sign<const FACTORS: usize>(positive: bool, term: [&Self; FACTORS]) -> Sign {
        let mut sign = if positive { Plus } else { Minus };
        for factor in term {
            sign = sign * factor.sign;
        }
        sign
    }

    fn product_sum_dyadic_plan<const TERMS: usize, const FACTORS: usize>(
        terms: [[&Self; FACTORS]; TERMS],
        signs: [Sign; TERMS],
    ) -> Option<DyadicProductSumPlan<TERMS>> {
        let mut max_shift = 0_u64;
        let mut denominator_shifts = [0_u64; TERMS];
        let mut numerator_bits = [0_u64; TERMS];
        let mut live_terms = 0_u64;
        for i in 0..TERMS {
            if signs[i] == NoSign {
                continue;
            }
            live_terms += 1;
            let mut shift = 0_u64;
            for factor in terms[i] {
                shift =
                    shift.checked_add(factor.dyadic_denominator_shift_if_reduced()?)?;
                numerator_bits[i] = numerator_bits[i].saturating_add(factor.numerator.bits());
            }
            denominator_shifts[i] = shift;
            max_shift = max_shift.max(shift);
        }
        let total_growth = live_terms.next_power_of_two().trailing_zeros();
        let prefer_wide = (0..TERMS).any(|i| {
            signs[i] != NoSign
                && numerator_bits[i]
                    .saturating_add(max_shift - denominator_shifts[i])
                    .saturating_add(u64::from(total_growth))
                    > u64::from(u128::BITS)
        });
        Some(DyadicProductSumPlan {
            denominator_shifts,
            max_shift,
            prefer_wide,
        })
    }

    fn signed_product_sum_dyadic_with_plan<const TERMS: usize, const FACTORS: usize>(
        terms: [[&Self; FACTORS]; TERMS],
        signs: [Sign; TERMS],
        denominator_shifts: [u64; TERMS],
        max_shift: u64,
    ) -> Self {
        let mut positive = BigUint::ZERO;
        let mut negative = BigUint::ZERO;
        for i in 0..TERMS {
            let sign = signs[i];
            if sign == NoSign {
                continue;
            }
            let scale_shift = usize::try_from(max_shift - denominator_shifts[i])
                .expect("dyadic product-sum scale should fit in usize");
            let mut magnitude = Self::product_term_magnitude(terms[i]);
            if scale_shift != 0 {
                magnitude <<= scale_shift;
            }
            match sign {
                Plus => positive += magnitude,
                Minus => negative += magnitude,
                NoSign => {}
            }
        }

        let denominator =
            BigUint::one() << usize::try_from(max_shift).expect("shift should fit in usize");
        Self::from_signed_magnitude_difference(
            positive,
            negative,
            denominator,
        )
    }

    fn signed_product_sum_dyadic_ordering_with_plan<const TERMS: usize, const FACTORS: usize>(
        terms: [[&Self; FACTORS]; TERMS],
        signs: [Sign; TERMS],
        denominator_shifts: [u64; TERMS],
        max_shift: u64,
    ) -> Ordering {
        let mut positive = BigUint::ZERO;
        let mut negative = BigUint::ZERO;
        for i in 0..TERMS {
            let sign = signs[i];
            if sign == NoSign {
                continue;
            }
            let scale_shift = usize::try_from(max_shift - denominator_shifts[i])
                .expect("dyadic product-sum scale should fit in usize");
            let mut magnitude = Self::product_term_magnitude(terms[i]);
            if scale_shift != 0 {
                magnitude <<= scale_shift;
            }
            match sign {
                Plus => positive += magnitude,
                Minus => negative += magnitude,
                NoSign => {}
            }
        }
        positive.cmp(&negative)
    }

    fn signed_product_sum_dyadic_wide_narrow_ordering_with_plan<
        const TERMS: usize,
        const FACTORS: usize,
    >(
        terms: [[&Self; FACTORS]; TERMS],
        signs: [Sign; TERMS],
        denominator_shifts: [u64; TERMS],
        max_shift: u64,
    ) -> Option<Ordering> {
        if FACTORS != 2 {
            return None;
        }
        let fixed_magnitude = |value: &BigUint| {
            if value.bits() > 256 {
                return None;
            }
            let mut words = [0_u64; 4];
            for (index, word) in value.iter_u64_digits().enumerate() {
                words[index] = word;
            }
            Some(words)
        };
        let mut positive = DyadicStackAccumulator::default();
        let mut negative = DyadicStackAccumulator::default();
        for i in 0..TERMS {
            let accumulator = match signs[i] {
                Plus => &mut positive,
                Minus => &mut negative,
                NoSign => continue,
            };
            let left = &terms[i][0].numerator;
            let right = &terms[i][1].numerator;
            let (wide, narrow) = if let Some(narrow) = right.to_u128() {
                (fixed_magnitude(left)?, narrow)
            } else {
                (fixed_magnitude(right)?, left.to_u128()?)
            };
            accumulator.add_wide_word_product(
                wide,
                narrow,
                max_shift - denominator_shifts[i],
            )?;
        }
        Some(positive.0.iter().rev().cmp(negative.0.iter().rev()))
    }

    /// Evaluate a signed product sum when every live factor shares one
    /// reduced denominator.
    ///
    /// The caller is expected to have carried an object-level common-scale
    /// certificate, but this method still validates the denominator fact before
    /// using it. Returning `None` means the certificate was too weak for this
    /// particular product shape, so callers should fall back to
    /// [`Self::signed_product_sum`]. Keeping the validation in `Rational`
    /// preserves scalar storage ownership while giving geometric kernels a
    /// denominator-specialized schedule. The final delayed reduction uses the
    /// same fraction-delay strategy as the generic reducer.
    pub fn signed_product_sum_shared_denominator<const TERMS: usize, const FACTORS: usize>(
        positive_terms: [bool; TERMS],
        terms: [[&Self; FACTORS]; TERMS],
    ) -> Option<Self> {
        debug_assert!(FACTORS > 0);
        let mut signs = [NoSign; TERMS];
        let mut nonzero_count = 0_usize;
        let mut shared_denominator = None::<&BigUint>;
        for i in 0..TERMS {
            let sign = Self::product_term_sign(positive_terms[i], terms[i]);
            if sign == NoSign {
                signs[i] = sign;
                continue;
            }
            nonzero_count += 1;
            signs[i] = sign;
            for factor in terms[i] {
                match shared_denominator {
                    None => shared_denominator = Some(&factor.denominator),
                    Some(shared) if shared == &factor.denominator => {}
                    Some(_) => return None,
                }
            }
        }
        if nonzero_count == 0 {
            crate::trace_dispatch!(
                "rational",
                "product_sum",
                "shared-factor-denominator-all-zero"
            );
            return Some(Self::zero());
        }
        if let Some(word) = Self::signed_product_sum_words(terms, signs) {
            crate::trace_dispatch!("rational", "product_sum", "word-sized-shared-scale");
            return Some(word);
        }
        let exponent = u32::try_from(FACTORS).ok()?;
        let denominator = shared_denominator
            .expect("nonzero product sum has a live factor denominator")
            .pow(exponent);
        let mut positive = BigUint::ZERO;
        let mut negative = BigUint::ZERO;
        for i in 0..TERMS {
            let sign = signs[i];
            if sign == NoSign {
                continue;
            }
            let magnitude = Self::product_term_magnitude(terms[i]);
            match sign {
                Plus => positive += magnitude,
                Minus => negative += magnitude,
                NoSign => {}
            }
        }
        crate::trace_dispatch!("rational", "product_sum", "shared-factor-denominator");
        Some(Self::from_signed_magnitude_difference(
            positive,
            negative,
            denominator,
        ))
    }

    /// Return the exact arithmetic mean of borrowed rationals, reducing once.
    ///
    /// The denominator schedule is built across the complete input before the
    /// final division by the number of values. This avoids reducing every
    /// partial sum and then reducing the quotient again.
    pub fn mean_refs(values: &[&Self]) -> Option<Self> {
        if values.is_empty() {
            return None;
        }
        let count = BigUint::from(values.len());
        Some(Self::sum_refs_with_denominator_factor(values, &count))
    }

    /// Return the exact arithmetic mean of three borrowed rationals.
    ///
    /// The fixed-size schedule avoids constructing a potentially expensive
    /// pairwise LCM before the final reduction. This is useful for geometric
    /// centroids whose projective coordinates often carry large, related
    /// denominators.
    pub fn mean3_refs(values: [&Self; 3]) -> Self {
        let values = values.map(Self::canonicalized_ref);
        let mut live_count = 0_usize;
        let mut shared_denominator = None::<&BigUint>;
        let mut equal_denominator = true;
        for value in values {
            if value.sign == NoSign {
                continue;
            }
            live_count += 1;
            match shared_denominator {
                None => shared_denominator = Some(&value.denominator),
                Some(shared) if shared == &value.denominator => {}
                Some(_) => equal_denominator = false,
            }
        }
        if live_count == 0 {
            crate::trace_dispatch!("rational", "mean3", "all-zero");
            return Self::zero();
        }
        if equal_denominator {
            let mut positive = BigUint::ZERO;
            let mut negative = BigUint::ZERO;
            for value in values {
                match value.sign {
                    Plus => positive += &value.numerator,
                    Minus => negative += &value.numerator,
                    NoSign => {}
                }
            }
            let denominator = shared_denominator
                .expect("nonzero three-value mean has a shared denominator")
                * BigUint::from(3_u8);
            crate::trace_dispatch!("rational", "mean3", "equal-denominator");
            return Self::from_signed_magnitude_difference(positive, negative, denominator);
        }

        let mut positive = BigUint::ZERO;
        let mut negative = BigUint::ZERO;
        for index in 0..3 {
            let value = values[index];
            if value.sign == NoSign {
                continue;
            }
            let mut magnitude = value.numerator.clone();
            magnitude *= &values[(index + 1) % 3].denominator;
            magnitude *= &values[(index + 2) % 3].denominator;
            match value.sign {
                Plus => positive += magnitude,
                Minus => negative += magnitude,
                NoSign => {}
            }
        }
        let denominator01 = &values[0].denominator * &values[1].denominator;
        let mut denominator = &denominator01 * &values[2].denominator;
        denominator *= BigUint::from(3_u8);
        crate::trace_dispatch!("rational", "mean3", "direct-product-denominator");
        Self::from_signed_magnitude_difference(positive, negative, denominator)
    }

    fn sum_refs_with_denominator_factor(values: &[&Self], factor: &BigUint) -> Self {
        let mut live_count = 0_usize;
        let mut common_dyadic_shift = Some(0_u64);
        let mut shared_denominator = None::<&BigUint>;
        let mut equal_denominator = true;
        for &value in values {
            let value = value.canonicalized_ref();
            if value.sign == NoSign {
                continue;
            }
            live_count += 1;
            common_dyadic_shift = match (common_dyadic_shift, value.dyadic_denominator_shift()) {
                (Some(current), Some(shift)) => Some(current.max(shift)),
                _ => None,
            };
            match shared_denominator {
                None => shared_denominator = Some(&value.denominator),
                Some(shared) if shared == &value.denominator => {}
                Some(_) => equal_denominator = false,
            }
        }
        if live_count == 0 {
            crate::trace_dispatch!("rational", "mean", "all-zero");
            return Self::zero();
        }

        if let Some(common_shift) = common_dyadic_shift {
            let mut positive = BigUint::ZERO;
            let mut negative = BigUint::ZERO;
            for &value in values {
                let value = value.canonicalized_ref();
                if value.sign == NoSign {
                    continue;
                }
                let shift = value
                    .dyadic_denominator_shift()
                    .expect("all live mean inputs were certified dyadic");
                let magnitude = &value.numerator << (common_shift - shift);
                match value.sign {
                    Plus => positive += magnitude,
                    Minus => negative += magnitude,
                    NoSign => {}
                }
            }
            let mut denominator = BigUint::one() << common_shift;
            denominator *= factor;
            crate::trace_dispatch!("rational", "mean", "dyadic-shared-denominator");
            return Self::from_signed_magnitude_difference(positive, negative, denominator);
        }

        if equal_denominator {
            let mut positive = BigUint::ZERO;
            let mut negative = BigUint::ZERO;
            for &value in values {
                let value = value.canonicalized_ref();
                match value.sign {
                    Plus => positive += &value.numerator,
                    Minus => negative += &value.numerator,
                    NoSign => {}
                }
            }
            let mut denominator = shared_denominator
                .expect("nonzero mean has a shared denominator")
                .clone();
            denominator *= factor;
            crate::trace_dispatch!("rational", "mean", "equal-denominator");
            return Self::from_signed_magnitude_difference(positive, negative, denominator);
        }

        let mut common_denominator = BigUint::one();
        for &value in values {
            let value = value.canonicalized_ref();
            if value.sign == NoSign {
                continue;
            }
            if value.denominator != *ONE.deref() {
                let divisor = Self::gcd_magnitudes_with_mixed_width_fast_path(
                    &common_denominator,
                    &value.denominator,
                );
                trace_rational_gcd!(&common_denominator, &value.denominator, &divisor);
                common_denominator *= &value.denominator / &divisor;
            }
        }

        let mut positive = BigUint::ZERO;
        let mut negative = BigUint::ZERO;
        for &value in values {
            let value = value.canonicalized_ref();
            if value.sign == NoSign {
                continue;
            }
            let mut magnitude = value.numerator.clone();
            if value.denominator != common_denominator {
                magnitude *= &common_denominator / &value.denominator;
            }
            match value.sign {
                Plus => positive += magnitude,
                Minus => negative += magnitude,
                NoSign => {}
            }
        }
        common_denominator *= factor;
        crate::trace_dispatch!("rational", "mean", "lcm-shared-denominator");
        Self::from_signed_magnitude_difference(positive, negative, common_denominator)
    }

    /// Evaluate a fixed-size signed sum of products exactly.
    ///
    /// Each row in `terms` is multiplied, then added or subtracted according to
    /// the matching entry in `positive_terms`. The implementation delays
    /// rational reduction until the final sum and has structural fast paths for
    /// dyadic and equal-denominator products. This is the scalar reducer that
    /// geometry crates use for small determinant schedules while preserving
    /// their abstraction boundary: they pass a known polynomial shape, but do
    /// not inspect `Rational` storage internals.
    ///
    /// The fraction-delay strategy keeps algebraic object shape visible before
    /// scalar expansion.
    pub fn signed_product_sum2(
        positive_terms: [bool; 2],
        terms: [[&Self; 2]; 2],
    ) -> Self {
        let signs = [
            Self::product_term_sign(positive_terms[0], terms[0]),
            Self::product_term_sign(positive_terms[1], terms[1]),
        ];
        if let Some(word) = Self::signed_product_sum_words(terms, signs) {
            crate::trace_dispatch!("rational", "product_sum", "fixed-two-by-two-word-sized");
            return word;
        }
        crate::trace_dispatch!("rational", "product_sum", "fixed-two-by-two-fallback");
        Self::signed_product_sum(positive_terms, terms)
    }

    /// Evaluate a signed sum of two-factor dyadic products exactly.
    ///
    /// The caller must have already proved that every factor is dyadic. This
    /// avoids making general exact-rational product sums repeatedly inspect
    /// denominators just to discover that the dyadic schedule does not apply.
    #[doc(hidden)]
    pub fn signed_product_sum_known_dyadic<const TERMS: usize>(
        positive_terms: [bool; TERMS],
        terms: [[&Self; 2]; TERMS],
    ) -> Self {
        let terms = terms.map(|term| term.map(Self::canonicalized_ref));
        let signs: [Sign; TERMS] = core::array::from_fn(|index| {
            Self::product_term_sign(positive_terms[index], terms[index])
        });
        crate::trace_dispatch!("rational", "product_sum", "known-dyadic-two-factor");
        Self::dot_products_dyadic(
            core::array::from_fn(|index| terms[index][0]),
            core::array::from_fn(|index| terms[index][1]),
            signs,
        )
        .expect("known-dyadic product sum received a non-dyadic factor")
    }

    pub(crate) fn quotient_known_dyadic(
        numerator: &Self,
        denominator: &Self,
    ) -> Result<Self, crate::Problem> {
        let numerator = numerator.canonicalized_ref();
        let denominator = denominator.canonicalized_ref();
        if denominator.sign == NoSign {
            return Err(crate::Problem::DivideByZero);
        }
        if numerator.sign == NoSign {
            return Ok(Self::zero());
        }
        let numerator_shift = numerator
            .dyadic_denominator_shift()
            .expect("known-dyadic numerator has a power-of-two denominator");
        let denominator_shift = denominator
            .dyadic_denominator_shift()
            .expect("known-dyadic denominator has a power-of-two denominator");
        if let (Some(numerator_word), Some(denominator_word), Ok(scale_shift)) = (
            numerator.numerator.to_u128(),
            denominator.numerator.to_u128(),
            i32::try_from(i128::from(denominator_shift) - i128::from(numerator_shift)),
        ) && let Some(result) = Self::from_scaled_dyadic_quotient_component(
            numerator.sign * denominator.sign,
            numerator_word,
            denominator_word,
            scale_shift,
        ) {
            crate::trace_dispatch!("rational", "div", "known-dyadic-word-cross-cancel");
            return Ok(result);
        }
        let divisor = Self::gcd_magnitudes_with_mixed_width_fast_path(
            &numerator.numerator,
            &denominator.numerator,
        );
        trace_rational_gcd!(&numerator.numerator, &denominator.numerator, &divisor);
        let (mut magnitude, mut scale) = if divisor.is_one() {
            (numerator.numerator.clone(), denominator.numerator.clone())
        } else {
            (
                &numerator.numerator / &divisor,
                &denominator.numerator / &divisor,
            )
        };
        if denominator_shift > numerator_shift {
            magnitude <<= usize::try_from(denominator_shift - numerator_shift)
                .expect("dyadic quotient shift fits usize");
        } else if numerator_shift > denominator_shift {
            scale <<= usize::try_from(numerator_shift - denominator_shift)
                .expect("dyadic quotient shift fits usize");
        }
        crate::trace_dispatch!("rational", "div", "known-dyadic-cross-cancel");
        trace_rational_temporary!();
        Ok(Self::from_parts_raw(
            numerator.sign * denominator.sign,
            magnitude,
            scale,
        ))
    }

    fn quotient_known_dyadic_with_word_divisor(
        numerator: &Self,
        denominator: &Self,
        numerator_shift: u64,
        denominator_shift: u64,
        denominator_word: u128,
        divisor: u128,
    ) -> (Self, bool) {
        if let (Some(numerator_word), Ok(scale_shift)) = (
            numerator.numerator.to_u128(),
            i32::try_from(i128::from(denominator_shift) - i128::from(numerator_shift)),
        ) && let Some(result) = Self::from_scaled_dyadic_quotient_component_with_divisor(
            numerator.sign * denominator.sign,
            numerator_word,
            denominator_word,
            scale_shift,
            divisor,
        ) {
            return (result, true);
        }

        let mut magnitude = if divisor == 1 {
            numerator.numerator.clone()
        } else {
            &numerator.numerator / divisor
        };
        let mut scale = BigUint::from(denominator_word / divisor);
        if denominator_shift > numerator_shift {
            magnitude <<= usize::try_from(denominator_shift - numerator_shift)
                .expect("dyadic quotient shift fits usize");
        } else if numerator_shift > denominator_shift {
            scale <<= usize::try_from(numerator_shift - denominator_shift)
                .expect("dyadic quotient shift fits usize");
        }
        trace_rational_temporary!();
        (
            Self::from_parts_raw(numerator.sign * denominator.sign, magnitude, scale),
            false,
        )
    }

    fn quotient_dyadic_stack_sum_with_word_divisor(
        numerator: DyadicStackSum,
        denominator_sign: Sign,
        denominator_shift: u64,
        denominator_word: u128,
        divisor: u128,
    ) -> Self {
        debug_assert_ne!(numerator.sign, NoSign);
        if let (Some(numerator_word), Ok(scale_shift)) = (
            numerator.magnitude.to_u128(),
            i32::try_from(
                i128::from(denominator_shift) - i128::from(numerator.denominator_shift),
            ),
        ) && let Some(result) = Self::from_scaled_dyadic_quotient_component_with_divisor(
            numerator.sign * denominator_sign,
            numerator_word,
            denominator_word,
            scale_shift,
            divisor,
        ) {
            return result;
        }

        let mut magnitude = numerator.magnitude.into_biguint();
        if divisor != 1 {
            debug_assert_eq!((&magnitude % divisor).to_u128(), Some(0));
            magnitude /= divisor;
        }
        let mut scale = BigUint::from(denominator_word / divisor);
        if denominator_shift > numerator.denominator_shift {
            magnitude <<= usize::try_from(denominator_shift - numerator.denominator_shift)
                .expect("dyadic quotient shift fits usize");
        } else if numerator.denominator_shift > denominator_shift {
            scale <<= usize::try_from(numerator.denominator_shift - denominator_shift)
                .expect("dyadic quotient shift fits usize");
        }
        trace_rational_temporary!();
        Self::from_parts_raw(numerator.sign * denominator_sign, magnitude, scale)
    }

    fn quotient_dyadic_stack_sum_unreduced(
        numerator: DyadicStackSum,
        denominator_sign: Sign,
        denominator_shift: u64,
        denominator_word: u128,
    ) -> Self {
        debug_assert_ne!(numerator.sign, NoSign);
        if let (Some(numerator_word), Ok(scale_shift)) = (
            numerator.magnitude.to_u128(),
            i32::try_from(
                i128::from(denominator_shift) - i128::from(numerator.denominator_shift),
            ),
        ) && let Some(result) = Self::from_scaled_dyadic_quotient_component_unreduced(
            numerator.sign * denominator_sign,
            numerator_word,
            denominator_word,
            scale_shift,
        ) {
            return result;
        }

        let mut magnitude = numerator.magnitude.into_biguint();
        let mut scale = BigUint::from(denominator_word);
        if denominator_shift > numerator.denominator_shift {
            magnitude <<= usize::try_from(denominator_shift - numerator.denominator_shift)
                .expect("dyadic quotient shift fits usize");
        } else if numerator.denominator_shift > denominator_shift {
            scale <<= usize::try_from(numerator.denominator_shift - denominator_shift)
                .expect("dyadic quotient shift fits usize");
        }
        trace_rational_temporary!();
        Self::from_parts_raw_unreduced(
            numerator.sign * denominator_sign,
            magnitude,
            scale,
        )
    }

    fn dyadic_wide_magnitude(value: DyadicWideWord) -> BigUint {
        let last = value
            .magnitude
            .iter()
            .rposition(|limb| *limb != 0)
            .expect("nonzero wide dyadic word has a nonzero limb");
        let mut digits = Vec::with_capacity((last + 1) * 2);
        for limb in &value.magnitude[..=last] {
            digits.push(*limb as u32);
            digits.push((*limb >> 32) as u32);
        }
        while digits.last() == Some(&0) {
            digits.pop();
        }
        BigUint::new(digits)
    }

    fn quotient_dyadic_wide_words(
        numerator: DyadicWideWord,
        denominator: DyadicWideWord,
        unreduced: bool,
    ) -> Self {
        debug_assert_ne!(denominator.sign, NoSign);
        if numerator.sign == NoSign {
            return Self::zero();
        }
        let mut magnitude = Self::dyadic_wide_magnitude(numerator);
        let mut scale = Self::dyadic_wide_magnitude(denominator);
        if denominator.denominator_shift > numerator.denominator_shift {
            magnitude <<= usize::try_from(
                denominator.denominator_shift - numerator.denominator_shift,
            )
            .expect("dyadic quotient shift fits usize");
        } else if numerator.denominator_shift > denominator.denominator_shift {
            scale <<= usize::try_from(
                numerator.denominator_shift - denominator.denominator_shift,
            )
            .expect("dyadic quotient shift fits usize");
        }
        let sign = numerator.sign * denominator.sign;
        if unreduced {
            trace_rational_temporary!();
            Self::from_parts_raw_unreduced(sign, magnitude, scale)
        } else {
            Self::from_bigint_fraction(BigInt::from_biguint(sign, magnitude), scale)
                .expect("retained nonzero determinant is a valid rational divisor")
        }
    }

    fn quotient_dyadic_stack_sum_by_wide_unreduced(
        numerator: DyadicStackSum,
        denominator: DyadicWideWord,
    ) -> Self {
        debug_assert_ne!(numerator.sign, NoSign);
        let mut magnitude = numerator.magnitude.into_biguint();
        let mut scale = Self::dyadic_wide_magnitude(denominator);
        if denominator.denominator_shift > numerator.denominator_shift {
            magnitude <<= usize::try_from(
                denominator.denominator_shift - numerator.denominator_shift,
            )
            .expect("dyadic quotient shift fits usize");
        } else if numerator.denominator_shift > denominator.denominator_shift {
            scale <<= usize::try_from(
                numerator.denominator_shift - denominator.denominator_shift,
            )
            .expect("dyadic quotient shift fits usize");
        }
        trace_rational_temporary!();
        Self::from_parts_raw_unreduced(
            numerator.sign * denominator.sign,
            magnitude,
            scale,
        )
    }

    /// Solve a proper crossing between four exact dyadic points without
    /// materializing coordinate deltas or determinant rationals. Returns
    /// `None` when a word or fixed-stack bound is exceeded so the caller can
    /// retain its arbitrary-precision construction.
    pub(crate) fn line_intersection2_point_known_dyadic(
        first_start: [&Self; 2],
        first_end: [&Self; 2],
        second_start: [&Self; 2],
        second_end: [&Self; 2],
    ) -> Option<(ExactDyadicLineParameters2, [Self; 2])> {
        let plan = Self::line_intersection2_plan_known_dyadic(
            first_start,
            first_end,
            second_start,
            second_end,
        )?;
        let point = Self::line_intersection2_point_from_plan(plan)?;
        crate::trace_dispatch!("rational", "line-intersection2", "dyadic-stack-fused-point");
        Some((
            ExactDyadicLineParameters2::from_words(plan.numerators, plan.denominator),
            point,
        ))
    }

    pub(crate) fn line_intersection2_point_with_first_line(
        first: &ExactDyadicLine2,
        second_start: [&Self; 2],
        second_end: [&Self; 2],
    ) -> Option<(ExactDyadicLineParameters2, [Self; 2])> {
        let plan =
            Self::line_intersection2_plan_with_first_line(first, second_start, second_end)?;
        let point = Self::line_intersection2_point_from_plan(plan)?;
        crate::trace_dispatch!(
            "rational",
            "line-intersection2",
            "dyadic-stack-fused-point-first-line"
        );
        Some((
            ExactDyadicLineParameters2::from_words(plan.numerators, plan.denominator),
            point,
        ))
    }

    pub(crate) fn line_intersection2_point_with_first_line_exact_dyadic_f64(
        first: &ExactDyadicLine2,
        second_start: [f64; 2],
        second_end: [f64; 2],
    ) -> Option<(ExactDyadicLineParameters2, [Self; 2])> {
        let plan = Self::line_intersection2_plan_with_first_line_exact_dyadic_f64(
            first,
            second_start,
            second_end,
        )?;
        let point = Self::line_intersection2_point_from_plan(plan)?;
        crate::trace_dispatch!(
            "rational",
            "line-intersection2",
            "dyadic-stack-fused-point-first-line-f64"
        );
        Some((
            ExactDyadicLineParameters2::from_words(plan.numerators, plan.denominator),
            point,
        ))
    }

    pub(crate) fn line_intersection2_retained_point_with_first_line_exact_dyadic_f64(
        first: &ExactDyadicLine2,
        second_start: [f64; 2],
        second_end: [f64; 2],
    ) -> Option<(ExactDyadicLineParameters2, ExactDyadicLinePoint2)> {
        let plan = Self::line_intersection2_plan_with_first_line_exact_dyadic_f64(
            first,
            second_start,
            second_end,
        )?;
        let point = Self::line_intersection2_retained_point_from_plan(plan)?;
        crate::trace_dispatch!(
            "rational",
            "line-intersection2",
            "dyadic-stack-retained-point-first-line-f64"
        );
        Some((
            ExactDyadicLineParameters2::from_words(plan.numerators, plan.denominator),
            point,
        ))
    }

    pub(crate) fn line_intersection2_point_known_dyadic_wide(
        first_start: [&Self; 2],
        first_end: [&Self; 2],
        second_start: [&Self; 2],
        second_end: [&Self; 2],
    ) -> Option<(ExactDyadicWideLineParameters2, [Self; 2])> {
        let plan = Self::line_intersection2_wide_plan_known_dyadic(
            first_start,
            first_end,
            second_start,
            second_end,
        )?;
        let point = Self::line_intersection2_point_from_wide_plan(plan)?;
        crate::trace_dispatch!(
            "rational",
            "line-intersection2",
            "dyadic-stack-fused-point-wide"
        );
        Some((
            ExactDyadicWideLineParameters2::from_words(plan.numerators, plan.denominator),
            point,
        ))
    }

    pub(crate) fn line_intersection2_point_wide_with_first_line(
        first: &ExactDyadicLine2,
        second_start: [&Self; 2],
        second_end: [&Self; 2],
    ) -> Option<(ExactDyadicWideLineParameters2, [Self; 2])> {
        let plan = Self::line_intersection2_wide_plan_with_first_line(
            first,
            second_start,
            second_end,
        )?;
        let point = Self::line_intersection2_point_from_wide_plan(plan)?;
        crate::trace_dispatch!(
            "rational",
            "line-intersection2",
            "dyadic-stack-fused-point-wide-first-line"
        );
        Some((
            ExactDyadicWideLineParameters2::from_words(plan.numerators, plan.denominator),
            point,
        ))
    }

    pub(crate) fn line_intersection2_point_wide_with_first_line_exact_dyadic_f64(
        first: &ExactDyadicLine2,
        second_start: [f64; 2],
        second_end: [f64; 2],
    ) -> Option<(ExactDyadicWideLineParameters2, [Self; 2])> {
        let plan = Self::line_intersection2_wide_plan_with_first_line_exact_dyadic_f64(
            first,
            second_start,
            second_end,
        )?;
        let point = Self::line_intersection2_point_from_wide_plan(plan)?;
        crate::trace_dispatch!(
            "rational",
            "line-intersection2",
            "dyadic-stack-fused-point-wide-first-line-f64"
        );
        Some((
            ExactDyadicWideLineParameters2::from_words(plan.numerators, plan.denominator),
            point,
        ))
    }

    pub(crate) fn line_intersection2_retained_point_wide_with_first_line_exact_dyadic_f64(
        first: &ExactDyadicLine2,
        second_start: [f64; 2],
        second_end: [f64; 2],
    ) -> Option<(ExactDyadicWideLineParameters2, ExactDyadicWideLinePoint2)> {
        let plan = Self::line_intersection2_wide_plan_with_first_line_exact_dyadic_f64(
            first,
            second_start,
            second_end,
        )?;
        let point = Self::line_intersection2_retained_point_from_wide_plan(plan)?;
        crate::trace_dispatch!(
            "rational",
            "line-intersection2",
            "dyadic-stack-retained-point-wide-first-line-f64"
        );
        Some((
            ExactDyadicWideLineParameters2::from_words(plan.numerators, plan.denominator),
            point,
        ))
    }

    fn line_intersection2_point_from_wide_plan(
        plan: DyadicWideLineIntersectionPlan,
    ) -> Option<[Self; 2]> {
        let coordinate = |index: usize| {
            let affine = Self::product_sum_wide_narrow_words(
                [plan.denominator, plan.numerators[0]],
                [plan.first_start[index], plan.first_delta[index]],
                [true, true],
            )?;
            if affine.sign == NoSign {
                return Some(Self::zero());
            }
            Some(Self::quotient_dyadic_stack_sum_by_wide_unreduced(
                affine,
                plan.denominator,
            ))
        };
        Some([coordinate(0)?, coordinate(1)?])
    }

    fn line_intersection2_retained_point_from_wide_plan(
        plan: DyadicWideLineIntersectionPlan,
    ) -> Option<ExactDyadicWideLinePoint2> {
        let coordinate = |index: usize| {
            Self::product_sum_wide_narrow_words(
                [plan.denominator, plan.numerators[0]],
                [plan.first_start[index], plan.first_delta[index]],
                [true, true],
            )
        };
        Some(ExactDyadicWideLinePoint2 {
            coordinate_numerators: [coordinate(0)?, coordinate(1)?],
            denominator_magnitude: plan.denominator.magnitude,
            denominator_shift: plan.denominator.denominator_shift,
            denominator_sign: plan.denominator.sign,
        })
    }

    pub(crate) fn line_intersection2_known_dyadic(
        first_start: [&Self; 2],
        first_end: [&Self; 2],
        second_start: [&Self; 2],
        second_end: [&Self; 2],
    ) -> Option<(Self, Self, [Self; 2])> {
        let plan = Self::line_intersection2_plan_known_dyadic(
            first_start,
            first_end,
            second_start,
            second_end,
        )?;
        let (first_parameter, _) =
            Self::quotient_dyadic_words(plan.numerators[0], plan.denominator)?;
        let (second_parameter, _) =
            Self::quotient_dyadic_words(plan.numerators[1], plan.denominator)?;
        let point = Self::line_intersection2_point_from_plan(plan)?;
        crate::trace_dispatch!("rational", "line-intersection2", "dyadic-stack-fused");
        Some((first_parameter, second_parameter, point))
    }

    fn line_intersection2_point_from_plan(plan: DyadicLineIntersectionPlan) -> Option<[Self; 2]> {
        let coordinate = |index: usize| {
            let left = [plan.first_start[index], plan.numerators[0]];
            let right = [plan.denominator, plan.first_delta[index]];
            let affine = Self::product_sum2_dyadic_words_word(left, right, [true, true])
                .map(Self::dyadic_word_stack_sum)
                .or_else(|| Self::product_sum_dyadic_words(left, right, [true, true]))?;
            if affine.sign == NoSign {
                return Some(Self::zero());
            }
            Some(Self::quotient_dyadic_stack_sum_unreduced(
                affine,
                plan.denominator.sign,
                plan.denominator.denominator_shift,
                plan.denominator.magnitude,
            ))
        };
        Some([coordinate(0)?, coordinate(1)?])
    }

    fn line_intersection2_retained_point_from_plan(
        plan: DyadicLineIntersectionPlan,
    ) -> Option<ExactDyadicLinePoint2> {
        let coordinate = |index: usize| {
            let left = [plan.first_start[index], plan.numerators[0]];
            let right = [plan.denominator, plan.first_delta[index]];
            Self::product_sum2_dyadic_words_word(left, right, [true, true])
                .map(Self::dyadic_word_stack_sum)
                .or_else(|| Self::product_sum_dyadic_words(left, right, [true, true]))
        };
        Some(ExactDyadicLinePoint2 {
            coordinate_numerators: [coordinate(0)?, coordinate(1)?],
            denominator_magnitude: plan.denominator.magnitude,
            denominator_shift: plan.denominator.denominator_shift,
            denominator_sign: plan.denominator.sign,
        })
    }

    /// Construct `t = numerator / denominator` and both coordinates of
    /// `origin + t * delta` after the caller has proved every input dyadic.
    /// One native cancellation of the shared quotient is reused by all three
    /// results. For an odd quotient denominator, each affine cancellation is
    /// then completed from its coordinate delta: `origin * denominator`
    /// vanishes modulo the denominator, and dyadic normalization removes only
    /// invertible powers of two.
    pub(crate) fn parameterized_point2_known_dyadic(
        origin: [&Self; 2],
        delta: [&Self; 2],
        numerator: &Self,
        denominator: &Self,
    ) -> Result<(Self, [Self; 2]), crate::Problem> {
        let origin = origin.map(Self::canonicalized_ref);
        let delta = delta.map(Self::canonicalized_ref);
        let numerator = numerator.canonicalized_ref();
        let denominator = denominator.canonicalized_ref();
        if denominator.sign == NoSign {
            return Err(crate::Problem::DivideByZero);
        }
        let denominator_shift = denominator
            .dyadic_denominator_shift()
            .expect("known-dyadic denominator has a power-of-two denominator");
        let numerator_shift = numerator
            .dyadic_denominator_shift()
            .expect("known-dyadic numerator has a power-of-two denominator");
        let word_plan = numerator
            .numerator
            .to_u128()
            .zip(denominator.numerator.to_u128())
            .map(|(numerator_word, denominator_word)| {
                (
                    denominator_word,
                    Self::gcd_word(numerator_word, denominator_word),
                )
            });

        let parameter = if let Some((denominator_word, first_divisor)) = word_plan {
            #[cfg(feature = "dispatch-trace")]
            let divisor_trace = BigUint::from(first_divisor);
            trace_rational_gcd!(
                &numerator.numerator,
                &denominator.numerator,
                &divisor_trace
            );
            let (result, _word_result) = Self::quotient_known_dyadic_with_word_divisor(
                numerator,
                denominator,
                numerator_shift,
                denominator_shift,
                denominator_word,
                first_divisor,
            );
            crate::trace_dispatch!(
                "rational",
                "div",
                if _word_result {
                    "known-dyadic-word-cross-cancel"
                } else {
                    "known-dyadic-cross-cancel"
                }
            );
            result
        } else {
            Self::quotient_known_dyadic(numerator, denominator)?
        };

        let coordinates = std::array::from_fn(|index| {
            let terms = [[origin[index], denominator], [numerator, delta[index]]];
            let signs = [
                Self::product_term_sign(true, terms[0]),
                Self::product_term_sign(true, terms[1]),
            ];
            let stack_sum = Self::dot_products_known_dyadic_stack_sum(
                [terms[0][0], terms[1][0]],
                [terms[0][1], terms[1][1]],
                signs,
            );
            if stack_sum.is_some() {
                crate::trace_dispatch!("rational", "product_sum", "known-dyadic-two-factor");
                crate::trace_dispatch!("rational", "dot_product", "dyadic-stack-accumulator");
            }
            if let Some(stack_sum) = stack_sum
                && stack_sum.sign != NoSign
                && let Some((denominator_word, first_divisor)) = word_plan
                && denominator_word > 1
                && denominator_word % 2 == 1
                && let Some(delta_word) = delta[index].numerator.to_u128()
            {
                let remaining_denominator = denominator_word / first_divisor;
                let second_divisor = Self::gcd_word(delta_word, remaining_denominator);
                let divisor = first_divisor * second_divisor;
                #[cfg(feature = "dispatch-trace")]
                let numerator_trace = stack_sum.magnitude.into_biguint();
                #[cfg(feature = "dispatch-trace")]
                let divisor_trace = BigUint::from(divisor);
                trace_rational_gcd!(
                    &numerator_trace,
                    &denominator.numerator,
                    &divisor_trace
                );
                let result = Self::quotient_dyadic_stack_sum_with_word_divisor(
                    stack_sum,
                    denominator.sign,
                    denominator_shift,
                    denominator_word,
                    divisor,
                );
                crate::trace_dispatch!(
                    "rational",
                    "div",
                    "known-dyadic-affine-factor-cross-cancel"
                );
                return Ok(result);
            }

            let affine_numerator = stack_sum.map_or_else(
                || Self::signed_product_sum_known_dyadic([true, true], terms),
                Self::materialize_dyadic_stack_sum,
            );
            if affine_numerator.sign == NoSign {
                return Ok(Self::zero());
            }
            if let Some((denominator_word, first_divisor)) = word_plan
                && denominator_word > 1
                && denominator_word % 2 == 1
                && let Some(delta_word) = delta[index].numerator.to_u128()
            {
                let remaining_denominator = denominator_word / first_divisor;
                let second_divisor = Self::gcd_word(delta_word, remaining_denominator);
                let divisor = first_divisor * second_divisor;
                let affine_shift = affine_numerator
                    .dyadic_denominator_shift()
                    .expect("known-dyadic affine numerator has a power-of-two denominator");
                #[cfg(feature = "dispatch-trace")]
                let divisor_trace = BigUint::from(divisor);
                trace_rational_gcd!(
                    &affine_numerator.numerator,
                    &denominator.numerator,
                    &divisor_trace
                );
                let (result, _) = Self::quotient_known_dyadic_with_word_divisor(
                    &affine_numerator,
                    denominator,
                    affine_shift,
                    denominator_shift,
                    denominator_word,
                    divisor,
                );
                crate::trace_dispatch!(
                    "rational",
                    "div",
                    "known-dyadic-affine-factor-cross-cancel"
                );
                Ok(result)
            } else {
                Self::quotient_known_dyadic(&affine_numerator, denominator)
            }
        });
        let [x, y] = coordinates;

        Ok((parameter, [x?, y?]))
    }

    /// Evaluate a fixed-size signed sum of products exactly.
    ///
    /// This general entry point accepts any fixed product shape. Two products
    /// of two factors should use [`Self::signed_product_sum2`] so word-sized
    /// complex and determinant kernels can bypass the generic shape planner.
    pub fn signed_product_sum<const TERMS: usize, const FACTORS: usize>(
        positive_terms: [bool; TERMS],
        terms: [[&Self; FACTORS]; TERMS],
    ) -> Self {
        // Short determinant and cofactor polynomials are exact rational sums of
        // products. As with `dot_products`, build one denominator and reduce
        // only the final row. This targets the trace rows where fixed 3x3/4x4
        // inverse, division, and negative-powi kernels still paid repeated gcd
        // work after dot products had already been fused. The algebraic
        // strategy delays fractions and keeps the public fixed-size cofactor
        // formulas division-free.
        // Structural note: keep this hook scalar-local. Hyperlattice can use it
        // for exact cofactor and determinant kernels, while predicate and
        // triangulation crates should consume only the resulting exact signs or
        // values through their own abstraction boundaries.
        debug_assert!(FACTORS > 0);
        let mut signs = [NoSign; TERMS];
        let mut nonzero_count = 0_usize;
        for i in 0..TERMS {
            // Term signs are pure structural facts from stored rational signs.
            // Compute them once and reuse them across dyadic, equal-denominator,
            // and LCM reducers. This preserves Bareiss-style delayed reduction
            // while removing repeated sign walks from exact cofactor/determinant
            // product sums.
            let sign = Self::product_term_sign(positive_terms[i], terms[i]);
            if sign != NoSign {
                nonzero_count += 1;
            }
            signs[i] = sign;
        }
        if nonzero_count == 0 {
            crate::trace_dispatch!("rational", "product_sum", "all-zero");
            return Self::zero();
        }
        let dyadic_plan = Self::product_sum_dyadic_plan(terms, signs);
        let prefer_wide_dyadic = dyadic_plan
            .as_ref()
            .is_some_and(|plan| plan.prefer_wide);
        if !prefer_wide_dyadic {
            if let Some(plan) = dyadic_plan.as_ref()
                && let Some(word) = Self::signed_product_sum_dyadic_words_with_plan(
                    terms,
                    signs,
                    plan.denominator_shifts,
                    plan.max_shift,
                )
            {
                crate::trace_dispatch!("rational", "product_sum", "dyadic-word-accumulator");
                return word;
            }
            if dyadic_plan.is_none()
                && let Some(word) = Self::signed_product_sum_words(terms, signs)
            {
                crate::trace_dispatch!("rational", "product_sum", "word-sized");
                return word;
            }
        }
        if nonzero_count == 1 {
            for i in 0..TERMS {
                match signs[i] {
                    Plus => {
                        crate::trace_dispatch!("rational", "product_sum", "single-term-product");
                        let denominator = Self::product_term_denominator(terms[i]);
                        return Self::from_signed_magnitude_difference(
                            Self::product_term_magnitude(terms[i]),
                            BigUint::ZERO,
                            denominator,
                        );
                    }
                    Minus => {
                        crate::trace_dispatch!("rational", "product_sum", "single-term-product");
                        let denominator = Self::product_term_denominator(terms[i]);
                        return Self::from_signed_magnitude_difference(
                            BigUint::ZERO,
                            Self::product_term_magnitude(terms[i]),
                            denominator,
                        );
                    }
                    NoSign => {}
                }
            }
        }

        if let Some(plan) = dyadic_plan {
            // Structural-dispatch note: callers that know coordinates are
            // lifted from a common binary grid could pass that grid exponent
            // with the terms and jump directly to this reducer, avoiding the
            // exploratory denominator scans used by generic exact rationals.
            crate::trace_dispatch!("rational", "product_sum", "dyadic-shared-denominator");
            return Self::signed_product_sum_dyadic_with_plan(
                terms,
                signs,
                plan.denominator_shifts,
                plan.max_shift,
            );
        }

        let mut denominators: [BigUint; TERMS] = std::array::from_fn(|_| BigUint::ZERO);
        let mut shared_denominator = None::<BigUint>;
        let mut equal_denominator = true;
        for i in 0..TERMS {
            if signs[i] == NoSign {
                continue;
            }
            let denominator = Self::product_term_denominator(terms[i]);
            match &shared_denominator {
                None => shared_denominator = Some(denominator.clone()),
                Some(shared) if *shared == denominator => {}
                Some(_) => equal_denominator = false,
            }
            denominators[i] = denominator;
        }

        if equal_denominator {
            let denominator = shared_denominator.expect("nonzero product sum has denominator");
            let mut positive = BigUint::ZERO;
            let mut negative = BigUint::ZERO;
            for i in 0..TERMS {
                let sign = signs[i];
                if sign == NoSign {
                    continue;
                }
                let magnitude = Self::product_term_magnitude(terms[i]);
                match sign {
                    Plus => positive += magnitude,
                    Minus => negative += magnitude,
                    NoSign => {}
                }
            }

            crate::trace_dispatch!("rational", "product_sum", "equal-product-denominator");
            return Self::from_signed_magnitude_difference(positive, negative, denominator);
        }

        crate::trace_dispatch!("rational", "product_sum", "lcm-shared-denominator");
        let mut common_denominator = BigUint::one();
        for i in 0..TERMS {
            if signs[i] == NoSign {
                continue;
            }
            let denominator = &denominators[i];
            if denominator != ONE.deref() {
                let divisor =
                    Self::gcd_magnitudes_with_mixed_width_fast_path(&common_denominator, denominator);
                trace_rational_gcd!(&common_denominator, denominator, &divisor);
                common_denominator *= denominator / &divisor;
            }
        }

        let mut positive = BigUint::ZERO;
        let mut negative = BigUint::ZERO;
        for i in 0..TERMS {
            let sign = signs[i];
            if sign == NoSign {
                continue;
            }
            let mut magnitude = Self::product_term_magnitude(terms[i]);
            let denominator = &denominators[i];
            if denominator != &common_denominator {
                magnitude *= &common_denominator / denominator;
            }
            match sign {
                Plus => positive += magnitude,
                Minus => negative += magnitude,
                NoSign => {}
            }
        }

        Self::from_signed_magnitude_difference(positive, negative, common_denominator)
    }

    // Keep complete planning and arbitrary-precision reduction out of the
    // common exact word-accumulator dispatchers. This helper is deliberately
    // shared only after every direct path declines.
    #[inline(never)]
    fn signed_product_sum_ordering_fallback<const TERMS: usize, const FACTORS: usize>(
        terms: [[&Self; FACTORS]; TERMS],
        signs: [Sign; TERMS],
    ) -> Ordering {
        let dyadic_plan = Self::product_sum_dyadic_plan(terms, signs);
        let prefer_wide_dyadic = dyadic_plan
            .as_ref()
            .is_some_and(|plan| plan.prefer_wide);
        if !prefer_wide_dyadic {
            if let Some(plan) = dyadic_plan.as_ref()
                && let Some((positive, negative)) =
                    Self::signed_product_sum_dyadic_word_totals(
                        terms,
                        signs,
                        plan.denominator_shifts,
                        plan.max_shift,
                    )
            {
                crate::trace_dispatch!(
                    "rational",
                    "product_sum_ordering",
                    "dyadic-word-accumulator"
                );
                return positive.cmp(&negative);
            }
            if dyadic_plan.is_none()
                && let Some((positive, negative, _)) =
                    Self::signed_product_sum_word_totals(terms, signs)
            {
                crate::trace_dispatch!("rational", "product_sum_ordering", "word-sized");
                return positive.cmp(&negative);
            }
        }
        if TERMS == 4
            && FACTORS == 2
            && let Some(plan) = dyadic_plan.as_ref()
            && let Some(ordering) =
                Self::signed_product_sum_dyadic_wide_narrow_ordering_with_plan(
                    terms,
                    signs,
                    plan.denominator_shifts,
                    plan.max_shift,
                )
        {
            crate::trace_dispatch!(
                "rational",
                "product_sum_ordering",
                "dyadic-stack-accumulator"
            );
            return ordering;
        }

        if let Some(plan) = dyadic_plan {
            crate::trace_dispatch!(
                "rational",
                "product_sum_ordering",
                "arbitrary-precision-dyadic"
            );
            return Self::signed_product_sum_dyadic_ordering_with_plan(
                terms,
                signs,
                plan.denominator_shifts,
                plan.max_shift,
            );
        }

        let mut denominators: [BigUint; TERMS] = std::array::from_fn(|_| BigUint::ZERO);
        let mut shared_denominator = None::<BigUint>;
        let mut equal_denominator = true;
        for i in 0..TERMS {
            if signs[i] == NoSign {
                continue;
            }
            let denominator = Self::product_term_denominator(terms[i]);
            match &shared_denominator {
                None => shared_denominator = Some(denominator.clone()),
                Some(shared) if *shared == denominator => {}
                Some(_) => equal_denominator = false,
            }
            denominators[i] = denominator;
        }

        if equal_denominator {
            let mut positive = BigUint::ZERO;
            let mut negative = BigUint::ZERO;
            for i in 0..TERMS {
                match signs[i] {
                    Plus => positive += Self::product_term_magnitude(terms[i]),
                    Minus => negative += Self::product_term_magnitude(terms[i]),
                    NoSign => {}
                }
            }
            crate::trace_dispatch!(
                "rational",
                "product_sum_ordering",
                "arbitrary-precision-equal-denominator"
            );
            return positive.cmp(&negative);
        }

        let mut common_denominator = BigUint::one();
        for i in 0..TERMS {
            if signs[i] == NoSign {
                continue;
            }
            let denominator = &denominators[i];
            if denominator != ONE.deref() {
                let divisor =
                    Self::gcd_magnitudes_with_mixed_width_fast_path(&common_denominator, denominator);
                trace_rational_gcd!(&common_denominator, denominator, &divisor);
                common_denominator *= denominator / &divisor;
            }
        }

        let mut positive = BigUint::ZERO;
        let mut negative = BigUint::ZERO;
        for i in 0..TERMS {
            let sign = signs[i];
            if sign == NoSign {
                continue;
            }
            let denominator = &denominators[i];
            let mut magnitude = Self::product_term_magnitude(terms[i]);
            if denominator != &common_denominator {
                magnitude *= &common_denominator / denominator;
            }
            match sign {
                Plus => positive += magnitude,
                Minus => negative += magnitude,
                NoSign => {}
            }
        }
        crate::trace_dispatch!(
            "rational",
            "product_sum_ordering",
            "arbitrary-precision-lcm"
        );
        positive.cmp(&negative)
    }

    // Keep sign reconstruction and every complete arbitrary-width route out of
    // the common four- and six-product word accumulator. A declined word probe
    // reaches this helper with the original inputs, so no fallback capability
    // depends on partial fast-path state.
    #[inline(never)]
    fn signed_product_sum_ordering_after_unplanned_declines<
        const TERMS: usize,
        const FACTORS: usize,
    >(
        positive_terms: [bool; TERMS],
        terms: [[&Self; FACTORS]; TERMS],
    ) -> Ordering {
        let signs = std::array::from_fn(|i| Self::product_term_sign(positive_terms[i], terms[i]));
        let mut nonzero_count = 0_usize;
        let mut nonzero_index = 0_usize;
        for (index, sign) in signs.iter().copied().enumerate() {
            if sign != NoSign {
                nonzero_count += 1;
                nonzero_index = index;
            }
            if nonzero_count == 2 {
                break;
            }
        }
        match nonzero_count {
            0 => {
                crate::trace_dispatch!("rational", "product_sum_ordering", "all-zero");
                Ordering::Equal
            }
            1 => {
                crate::trace_dispatch!(
                    "rational",
                    "product_sum_ordering",
                    "single-term-product"
                );
                match signs[nonzero_index] {
                    Minus => Ordering::Less,
                    Plus => Ordering::Greater,
                    NoSign => unreachable!("the retained product term is nonzero"),
                }
            }
            _ => Self::signed_product_sum_ordering_fallback(terms, signs),
        }
    }

    /// Compare a fixed signed sum of products with zero without materializing
    /// or reducing the resulting rational.
    pub fn signed_product_sum_ordering<const TERMS: usize, const FACTORS: usize>(
        positive_terms: [bool; TERMS],
        terms: [[&Self; FACTORS]; TERMS],
    ) -> Ordering {
        debug_assert!(FACTORS > 0);
        // Expanded affine and 2D orientation determinants have four or six
        // pair products and overwhelmingly stay in the word-sized dyadic
        // envelope. Use the fourth affine factor as a conservative admission
        // guard; a rejected probe simply continues to the complete bit-width
        // plan. Compute signs inside this common path so its successful case
        // does not first materialize and rescan a separate sign array.
        if FACTORS == 2 && (TERMS == 4 || TERMS == 6) {
            if (TERMS == 6 || terms[3][0].numerator.to_u128().is_some())
                && let Some((positive, negative)) =
                Self::signed_product_sum_dyadic_word_totals_unplanned(positive_terms, terms)
            {
                crate::trace_dispatch!(
                    "rational",
                    "product_sum_ordering",
                    "dyadic-word-accumulator"
                );
                return positive.cmp(&negative);
            }
            return Self::signed_product_sum_ordering_after_unplanned_declines(
                positive_terms,
                terms,
            );
        }
        let signs = std::array::from_fn(|i| Self::product_term_sign(positive_terms[i], terms[i]));
        let mut nonzero_count = 0_usize;
        let mut nonzero_index = 0_usize;
        for (index, sign) in signs.iter().copied().enumerate() {
            if sign != NoSign {
                nonzero_count += 1;
                nonzero_index = index;
            }
            if nonzero_count == 2 {
                break;
            }
        }
        match nonzero_count {
            0 => {
                crate::trace_dispatch!("rational", "product_sum_ordering", "all-zero");
                return Ordering::Equal;
            }
            1 => {
                crate::trace_dispatch!("rational", "product_sum_ordering", "single-term-product");
                return match signs[nonzero_index] {
                    Minus => Ordering::Less,
                    Plus => Ordering::Greater,
                    NoSign => unreachable!("the retained product term is nonzero"),
                };
            }
            _ => {}
        }
        Self::signed_product_sum_ordering_fallback(terms, signs)
    }

    /// Compare a dynamically sized signed sum of two-factor products with
    /// zero without materializing the resulting rational.
    ///
    /// This complements [`Self::signed_product_sum_ordering`] for predicates
    /// whose number of terms is data-dependent, such as polygon area. The
    /// word-sized path keeps only scaled numerator totals; the arbitrary-width
    /// fallback likewise compares positive and negative magnitudes directly.
    pub fn signed_product_sum2_ordering_slice(
        positive_terms: &[bool],
        terms: &[[&Self; 2]],
    ) -> Ordering {
        assert_eq!(
            positive_terms.len(),
            terms.len(),
            "each rational product term must have a sign"
        );

        let signs: Vec<_> = positive_terms
            .iter()
            .zip(terms)
            .map(|(&positive, &term)| Self::product_term_sign(positive, term))
            .collect();
        let mut nonzero = signs
            .iter()
            .copied()
            .enumerate()
            .filter(|(_, sign)| *sign != NoSign);
        let Some((_first_index, first_sign)) = nonzero.next() else {
            crate::trace_dispatch!("rational", "product_sum_ordering_slice", "all-zero");
            return Ordering::Equal;
        };
        if nonzero.next().is_none() {
            crate::trace_dispatch!(
                "rational",
                "product_sum_ordering_slice",
                "single-term-product"
            );
            return match first_sign {
                Minus => Ordering::Less,
                Plus => Ordering::Greater,
                NoSign => unreachable!("the retained product term is nonzero"),
            };
        }

        let mut word_terms = Vec::with_capacity(terms.len());
        let mut word_common_denominator = 1_u128;
        let mut word_path = true;
        for (&sign, &term) in signs.iter().zip(terms) {
            if sign == NoSign {
                word_terms.push((0_u128, 1_u128));
                continue;
            }
            let Some((magnitude, denominator)) = Self::product_term_words(term) else {
                word_path = false;
                break;
            };
            let divisor = Self::gcd_word(word_common_denominator, denominator);
            let Some(common) =
                word_common_denominator.checked_mul(denominator / divisor)
            else {
                word_path = false;
                break;
            };
            word_common_denominator = common;
            word_terms.push((magnitude, denominator));
        }
        if word_path {
            let mut positive = 0_u128;
            let mut negative = 0_u128;
            for ((magnitude, denominator), sign) in
                word_terms.into_iter().zip(signs.iter().copied())
            {
                if sign == NoSign {
                    continue;
                }
                let Some(scaled) =
                    magnitude.checked_mul(word_common_denominator / denominator)
                else {
                    word_path = false;
                    break;
                };
                let total = match sign {
                    Plus => &mut positive,
                    Minus => &mut negative,
                    NoSign => unreachable!("zero terms were skipped"),
                };
                let Some(next) = total.checked_add(scaled) else {
                    word_path = false;
                    break;
                };
                *total = next;
            }
            if word_path {
                crate::trace_dispatch!(
                    "rational",
                    "product_sum_ordering_slice",
                    "word-sized"
                );
                return positive.cmp(&negative);
            }
        }

        crate::trace_dispatch!(
            "rational",
            "product_sum_ordering_slice",
            "arbitrary-precision"
        );
        let mut denominators = Vec::with_capacity(terms.len());
        let mut common_denominator = BigUint::one();
        for (&sign, &term) in signs.iter().zip(terms) {
            if sign == NoSign {
                denominators.push(BigUint::one());
                continue;
            }
            let denominator = Self::product_term_denominator(term);
            let divisor =
                Self::gcd_magnitudes_with_mixed_width_fast_path(&common_denominator, &denominator);
            common_denominator *= &denominator / &divisor;
            denominators.push(denominator);
        }
        let mut positive = BigUint::ZERO;
        let mut negative = BigUint::ZERO;
        for ((&sign, &term), denominator) in signs.iter().zip(terms).zip(&denominators) {
            if sign == NoSign {
                continue;
            }
            let mut magnitude = Self::product_term_magnitude(term);
            if denominator != &common_denominator {
                magnitude *= &common_denominator / denominator;
            }
            match sign {
                Plus => positive += magnitude,
                Minus => negative += magnitude,
                NoSign => unreachable!("zero terms were skipped"),
            }
        }
        positive.cmp(&negative)
    }

    pub(crate) fn dot_products<const N: usize>(left: [&Self; N], right: [&Self; N]) -> Self {
        // Dense vector and matrix dot products are exact rational linear
        // forms when all inputs are rational. Build one shared denominator and
        // canonicalize only the final sum instead of reducing every product
        // and partial sum, delaying fractions until the end.
        // Keep exact matrix rows at one rational
        // constructor per output cell. This dropped mat4 powi from-f64 trace
        // activity from 161.75 to 32 reductions/call and from 462.25 to 67.75
        // temporaries/call; keep future changes within noise of those counts.
        let mut signs = [NoSign; N];
        let mut nonzero_count = 0_usize;
        for i in 0..N {
            let sign = left[i].sign * right[i].sign;
            if sign != NoSign {
                nonzero_count += 1;
            }
            signs[i] = sign;
        }
        if nonzero_count == 0 {
            crate::trace_dispatch!("rational", "dot_product", "all-zero");
            return Self::zero();
        }
        let terms = std::array::from_fn(|i| [left[i], right[i]]);
        if let Some(word) = Self::signed_product_sum_words(terms, signs) {
            crate::trace_dispatch!("rational", "dot_product", "word-sized");
            return word;
        }
        if nonzero_count == 1 {
            let mut positive = BigUint::ZERO;
            let mut negative = BigUint::ZERO;
            for i in 0..N {
                match signs[i] {
                    Plus => {
                        let denominator = &left[i].denominator * &right[i].denominator;
                        positive = &left[i].numerator * &right[i].numerator;
                        crate::trace_dispatch!("rational", "dot_product", "single-term-product");
                        return Self::from_signed_magnitude_difference(
                            positive,
                            negative,
                            denominator,
                        );
                    }
                    Minus => {
                        let denominator = &left[i].denominator * &right[i].denominator;
                        negative = &left[i].numerator * &right[i].numerator;
                        crate::trace_dispatch!("rational", "dot_product", "single-term-product");
                        return Self::from_signed_magnitude_difference(
                            positive,
                            negative,
                            denominator,
                        );
                    }
                    NoSign => {}
                }
            }
            return Self::zero();
        }

        if let Some(dyadic) = Self::dot_products_dyadic(left, right, signs) {
            // Binary64-derived dyadics are the hottest exact-rational matrix path.
            // A common power-of-two denominator lets us scale numerators with
            // shifts and lets `maybe_reduce` avoid a BigInt gcd.
            // Structural-dispatch note: matrix/vector callers with retained
            // grid-scale metadata can route straight here and reserve the LCM
            // path for genuinely mixed rational inputs.
            crate::trace_dispatch!("rational", "dot_product", "dyadic-shared-denominator");
            return dyadic;
        }
        if let Some(equal_denominator) = Self::dot_products_equal_denominator(left, right, signs) {
            // Decimal rational fixtures often enter with identical product
            // denominators even after exact parsing. The LCM algorithm below is
            // still the right general fallback, but this structural fact means
            // there is no LCM to build and no per-term scale division. 2026-05
            // tracing target: lower non-dyadic rational dot-product gcd counts
            // without perturbing the dyadic fast path above. Targeted
            // Criterion, 200 samples/8s: hyperlattice hyperreal-rational
            // mat3 powi improved 2.83%, mat4 div_matrix improved 3.88%,
            // mat3 inverse_checked and mat4 powi stayed within noise.
            crate::trace_dispatch!("rational", "dot_product", "equal-product-denominator");
            return equal_denominator;
        }

        crate::trace_dispatch!("rational", "dot_product", "lcm-shared-denominator");
        let mut common_denominator = BigUint::one();
        let mut any_nonzero = false;
        for i in 0..N {
            if signs[i] == NoSign {
                continue;
            }
            let denominator = &left[i].denominator * &right[i].denominator;
            if denominator != *ONE.deref() {
                let divisor =
                    Self::gcd_magnitudes_with_mixed_width_fast_path(&common_denominator, &denominator);
                trace_rational_gcd!(&common_denominator, &denominator, &divisor);
                common_denominator *= denominator / &divisor;
            }
            any_nonzero = true;
        }
        if !any_nonzero {
            return Self::zero();
        }

        let mut positive = BigUint::ZERO;
        let mut negative = BigUint::ZERO;
        for i in 0..N {
            let sign = signs[i];
            if sign == NoSign {
                continue;
            }
            let denominator = &left[i].denominator * &right[i].denominator;
            let mut magnitude = &left[i].numerator * &right[i].numerator;
            if denominator != common_denominator {
                magnitude *= &common_denominator / denominator;
            }
            match sign {
                Plus => positive += magnitude,
                Minus => negative += magnitude,
                NoSign => {}
            }
        }

        Self::from_signed_magnitude_difference(positive, negative, common_denominator)
    }

    /// Reuse the ordinary bounded product and linear caches after a dense
    /// self-dot's leading coordinate has already been observed by borrowed
    /// arithmetic. Sparse rows keep the cheaper aggregate zero-pruned path.
    #[inline(never)]
    pub(crate) fn self_dot_if_reused<const N: usize>(values: [&Self; N]) -> Option<Self> {
        if values.iter().any(|value| value.sign == NoSign) {
            return None;
        }
        let (any_product, all_self_products) = values.iter().fold(
            (false, true),
            |(any_product, all_self_products), value| {
                let state = value.retained_primary_self_product_state();
                (any_product || state.is_some(), all_self_products && state == Some(true))
            },
        );
        if any_product {
            if !all_self_products && !Self::conflicted_self_dot_is_reusable(values) {
                return None;
            }
        } else if !values.first()?.has_arithmetic_reuse_evidence() {
            return None;
        }

        let products = values.map(|value| value * value);
        for product in &products {
            let _ = product.has_arithmetic_reuse_evidence();
        }
        let sum = if N == 4 {
            let left = &products[0] + &products[1];
            let right = &products[2] + &products[3];
            &left + &right
        } else {
            let mut products = products.into_iter();
            let mut sum = products.next()?;
            for product in products {
                sum = &sum + &product;
            }
            sum
        };
        crate::trace_dispatch!("rational", "dot_product", "retained-self-dot");
        Some(sum)
    }

    #[inline(never)]
    fn conflicted_self_dot_is_reusable<const N: usize>(values: [&Self; N]) -> bool {
        values
            .iter()
            .all(|value| value.has_retained_self_product())
            || values
                .first()
                .is_some_and(|value| value.admit_conflicted_self_dot_once())
    }

}
